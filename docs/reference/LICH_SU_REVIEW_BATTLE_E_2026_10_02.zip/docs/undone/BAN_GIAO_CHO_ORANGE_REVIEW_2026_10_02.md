# Blue-chan — các phần chờ Orange-kun review

**Cập nhật:** người dùng đã báo Orange-kun review xong các bản bên dưới và ghi phản hồi cuối từng file. Danh sách này giữ làm lịch sử bàn giao, không còn là danh sách toàn bộ chưa review. Lượt sửa tiếp theo xem [Tiếp nhận review Orange — canon, release và mobile](NOTE_TIEP_NHAN_REVIEW_ORANGE_CANON_MOBILE.md).

02/10/2026. Danh sách dựa trên phản hồi trong cuộc trò chuyện và ghi chú trong repo. **Chưa thấy xác nhận review** không có nghĩa Orange-kun chưa mở hoặc đọc file. Không thay code battle trong lượt gom tài liệu này.

## 1. Ba bản mới cần đọc trước

**Bổ sung sau danh sách ban đầu:** [Mở rộng sân, AI theo nhân vật và VFX](KE_HOACH_MO_RONG_SAN_AI_ROSTER_VFX.md) — người dùng đã thử PN–BNB tạm ổn, yêu cầu plan sân lớn/AI riêng/FX và chuẩn bị review 39 asset. Chỉ lập kế hoạch, chưa áp code. Review sau hoặc phối hợp với các bản tài nguyên/thời kỳ bên dưới.

| Thứ tự | Tài liệu | Phần cần review | Trạng thái |
|---|---|---|---|
| 1 | [Chân nguyên và nhịp dùng cổ](KE_HOACH_CHAN_NGUYEN_VA_NHIP_DUNG_CO.md) | Dung lượng biển, phẩm chất chân nguyên, hồi tự nhiên theo thời gian, nguyên thạch, phí duy trì, kiểm tra đủ phí khi release; chỉ thử giảm khóa chung sau khi ngân sách ổn | Kế hoạch, chưa áp cơ chế tài nguyên tổng thể |
| 2 | [Cân bằng cổ trùng và BNB theo mốc truyện](KE_HOACH_CAN_BANG_CO_TRUNG_VA_BNB_THEO_MOC_TRUYEN.md) | Các lần gặp BNB và trận ch.166, cổ theo thời kỳ, mất tay/mất cổ theo nhánh; bộ cổ cố định chỉ cho boss, PN dùng inventory thật | Kế hoạch; riêng Thiên Bồng đã áp theo dòng 3 |
| 3 | [Thiên Bồng 3s — bàn giao](NOTE_APPLY_THIEN_BONG_3S.md) | Vận đứng yên 0,9s; phí bật 18, duy trì 5/s trong tối đa 3s, ngừng regen khi giáp bật, cạn chân nguyên tắt sớm | Đã áp sandbox E; hồi quy logic đạt, chưa đo lại cân bằng/chơi thử điện thoại |

Code cần đọc cùng bản Thiên Bồng: [kits.js](../../js/sandbox/kits.js), [sim.js](../../js/sandbox/sim.js), [hud.js](../../js/sandbox/hud.js), [sandbox_regression.cjs](../../tools/sandbox_regression.cjs).

## 2. Các bản/phần bổ sung trước đó chưa thấy xác nhận

| Tài liệu | Phạm vi còn chờ | Trạng thái |
|---|---|---|
| [Khóa chung và boss BNB](NOTE_COOLDOWN_CHUNG_VA_BOSS_BNB.md) | Khóa 2s cho các cổ khác đang sẵn sàng, không kéo dài CD đang chạy; AI mức Khó và benchmark | Đã áp sandbox; các nhận định thời kỳ phải đối chiếu lại bản cân bằng mới ở mục 1 |
| [Ghi chú tích hợp sandbox E](NOTE_TICH_HOP_SANDBOX_E.md) | **Chỉ phần “Bàn giao Orange-kun — Blue-chan tiếp tục cân bằng di chuyển” và cập nhật cuối**: đòn đánh, Lốc, vững thế, sửa hủy zone, benchmark có seed | Đã áp; số liệu trước khóa 2s không đại diện runtime mới |
| [Chốt sandbox PN–BNB](KE_HOACH_CHOT_SANDBOX_PN_BNB.md) | KO ở mép sân, đo mọi pose, ứng viên biên mới, nhắm chiêu cảm ứng và nút Dừng | Kế hoạch, chưa triển khai các hạng mục này |
| [Map battle pixel](KE_HOACH_MAP_BATTLE_PIXEL.md) | **Mục 11 của Blue-chan**: KO hàng trước còn tràn khung, kiểm cấu hình ground_screen_y, đo trước khi đổi biên | Review bổ sung/đề xuất; bản map nền trước đó Orange đã review |
| [VFX và âm thanh](KE_HOACH_VFX_AM_THANH_BATTLE_E.md) | **Mục 12 của Blue-chan**: sửa độ cao đạn theo độ sâu, vòng đời event, loader âm, âm lượng khi nhiều cue cùng phát | Sửa độ cao đạn đã áp; bộ file âm/asset FX và các đề xuất còn lại chưa hoàn tất |

Báo cáo đo cũ để đối chiếu: [cân bằng di chuyển](../../tools/reports/sandbox_balance_2026_10_02.json), [khóa chung và AI](../../tools/reports/sandbox_gu_lock_2026_10_02.json). Không dùng chúng để kết luận thông số Thiên Bồng mới đã cân bằng.

## 3. Các điểm đã được người dùng chốt

- PN lấy cổ từ save/inventory thực tế theo diễn biến và nhánh lựa chọn. Không cấp bộ cổ theo màn, không whitelist để tước cổ người chơi đã sở hữu.
- Boss mới có bộ cổ theo thời kỳ; cần tính trạng thái mất tay/mất cổ và nhánh cứu Thanh Thư.
- Có hồi chân nguyên tự nhiên; nguyên thạch là cách bổ sung, không phải nguồn hồi duy nhất. Bản chân nguyên mới thay các giả định hồi nhanh hoặc chỉ hồi bằng nguyên thạch trước đó. Phải thống nhất đơn vị và hệ số thời gian battle trước khi chuyển số liệu truyện sang code.
- Băng Trùy có căn cứ ở giai đoạn ch.166; không dùng nhận định cũ “không có ở Q1” để loại khỏi mọi lần gặp. Đồng thời không cấp cổ giai đoạn đó vào màn Thanh Thư sớm hơn.
- Khóa chung vẫn 2s ở runtime. Giảm 2s → 1s → 0s chỉ là thử nghiệm đề xuất sau khi chi phí/hồi phục được xử lý.
- Thiên Bồng 3s là thay đổi đã được yêu cầu áp. Phí hủy 25%, nguyên thạch trong battle, upkeep các cổ khác và adapter inventory vẫn là kế hoạch.

## 4. Phần đã có phản hồi, không gửi lại như chưa review

- Review key-pose trong [Hướng dẫn gen hàng loạt](../prompts/HUONG_DAN_GEN_HANG_LOAT_KEYPOSE.md), mục 10–11: Orange đã phản hồi ở mục 12.
- [Prompt Muse roster](../prompts/PROMPT_MUSE_ROSTER.md): mục 6 đã ghi sửa theo review Blue-chan; vẫn còn xác minh từng nhân vật, nhưng không gọi toàn bộ bản này là chưa được phản hồi.
- Các sửa kết trận, Pointer Events, URL, idle timing và bóng lướt ban đầu: Orange đã báo kiểm lại và đồng ý giữ. Phần mới cần review của ghi chú sandbox được tách ở mục 2.
- Map và VFX nền: Orange đã review/cập nhật ở mục 10 và 11 tương ứng. Chỉ gửi thêm phản hồi Blue-chan sau đó.

## 5. Đoạn gửi Orange-kun

> Orange-kun đọc giúp danh sách bàn giao này. Ưu tiên bản chân nguyên → bản BNB theo mốc truyện → ghi chú Thiên Bồng đã áp. Sau đó kiểm các phần bổ sung ở mục 2. Hai kế hoạch mới chưa được triển khai toàn bộ; Thiên Bồng đã đổi sandbox và có hồi quy, nhưng chưa đo lại cân bằng. PN phải dùng inventory thật; chỉ boss có bộ cổ theo thời kỳ. Nhờ ghi phản hồi vào từng file, phân biệt lỗi cần sửa, đề xuất đồng ý và phần cần người dùng quyết định.
