# Mở rộng sân, AI theo nhân vật và VFX — Blue-chan gửi Orange-kun

**Cập nhật triển khai sau review:** đã thử sân 1200×260 nhìn toàn màn, lề view 127px, hướng Nguyệt công khai và AI BNB ép nhịp. [Bàn giao, benchmark và giới hạn](NOTE_APPLY_SAN_1200_AI_EP_NHIP.md). Các phần roster/FX/campaign còn là kế hoạch.

02/10/2026. Người dùng đã thử PN–BNB và thấy tạm ổn; bước tiếp là sân lớn hơn, AI thông minh hơn, phong cách đánh riêng và hiệu ứng đẹp hơn. **Đây là kế hoạch để review, chưa đổi runtime hoặc tạo asset.** Bộ 39 nhân vật người dùng sắp gửi cần được kiểm kê trước khi chốt roster và phạm vi triển khai.

Đọc cùng [chân nguyên](KE_HOACH_CHAN_NGUYEN_VA_NHIP_DUNG_CO.md), [BNB theo thời kỳ](KE_HOACH_CAN_BANG_CO_TRUNG_VA_BNB_THEO_MOC_TRUYEN.md), [map](KE_HOACH_MAP_BATTLE_PIXEL.md), [VFX/âm](KE_HOACH_VFX_AM_THANH_BATTLE_E.md) và [chốt sandbox/mobile](KE_HOACH_CHOT_SANDBOX_PN_BNB.md). Tài liệu này mở rộng các bản đó, không thay các yêu cầu về inventory PN hoặc nguồn nguyên tác.

## 1. Hiện trạng và mục tiêu

| Hiện tại đã đọc trong code | Hướng tiếp |
|---|---|
| `sim.js`: x=110…890, z=0…240, spawn PN/BNB cố định; `other()` chỉ biết hai actor | Cấu hình sân/spawn theo trận, chọn mục tiêu qua API; vẫn làm 1v1 trước |
| `view.js`: canvas 960×430, x quy đổi theo thế giới 1000, sàn theo `ground_screen_y`, scale theo z | Tách viewport khỏi kích thước thế giới; view/input dùng chung phép chiếu có nghịch đảo |
| `ai.js`: thứ tự if riêng BNB, gọi thẳng tên Lốc/Thủy Tráo/Sương Yêu | Bộ quyết định chung + hồ sơ chiến thuật từng nhân vật/thời kỳ |
| VFX chủ yếu Graphics, một số anchor/fallback, có audio tổng hợp | Asset FX riêng + registry nối với event và anchor đã duyệt |

Mục tiêu: có khoảng trống để né và đổi vị trí, nhưng vẫn gặp và giao chiến thường xuyên; AI biết chọn thời cơ và tiết kiệm tài nguyên; cùng độ khó nhưng các nhân vật có cách đánh khác nhau. Không coi tăng HP/sát thương là bằng chứng AI đã khôn hơn.

## 2. Sân lớn hơn: thử tăng không gian trước khi thêm camera

### Bản thử A — nhìn toàn sân

- Giữ viewport 960×430 và HUD hiện tại. Thử **world rộng 1400, sâu 320** so với hệ quy chiếu hiện tại 1000×240. Đây là ứng viên A/B, chưa phải giá trị chốt.
- Tách `worldRect` khỏi `playableBounds`: kích thước thế giới dùng phép chiếu; biên đi phải trừ margin của sprite. Không nhân 110/890 theo tỷ lệ rồi giả định KO/thú lớn sẽ vừa.
- Giữ kích thước sprite trên màn hình ở mức đọc được. Khi nhiều world unit đi vào cùng viewport, bước đi nhìn sẽ chậm hơn nếu speed không đổi; đo và lựa chọn rõ giữa giữ tốc độ world hay giữ tốc độ màn hình. Không tự tăng speed tất cả actor khi mở map.
- Đo `thời gian áp sát`, `thời gian thoát melee`, `thời gian vượt sân`, tỷ lệ tầm đạn/sân và thời gian né AoE. Ban đầu giữ range/damage/CD để tách tác động của sân; cân chỉnh movement ở lượt riêng nếu cần.
- Giữ phép chiếu sân phẳng kiểu hiện tại, chưa chuyển thành map ô hay pathfinding toàn bản đồ. Nền mới cần bãi đất rộng, mép sau rõ, khoảng trống hai bên; không kéo giãn nền trúc cũ để nghiệm thu mỹ thuật.
- Sinh tọa độ spawn từ cấu hình, tính khoảng cách bắt đầu có chủ đích. Kiểm KO và pose rộng ở bốn góc, cả hai hướng mặt, mọi depth; không giải quyết clipping bằng thu nhỏ riêng mỗi pose.

**Thiết kế dữ liệu đề xuất:** `worldRect`, `playableBounds`, `spawns`, `ground_screen_y`, `image`, `pixel`, `haze`, `cameraMode`. Quy định đơn vị world/màn hình rõ, validate số hữu hạn, biên có thứ tự, spawn trong sân; thiếu cấu hình dùng baseline cũ. Khi simulation được cấu hình theo trận, bỏ việc các subsystem tự đọc hằng số toàn cục `SBSim.Z1/X0/X1` cho một trận có kích thước khác.

### Bản thử B — camera, chỉ khi bản A làm actor khó đọc

- Giữ tỷ lệ actor; camera theo trung điểm hai bên, giới hạn tốc độ pan và zoom tối thiểu. Chưa bật rung camera trong giai đoạn này.
- Khi hai bên ở xa, ưu tiên zoom vừa đủ thấy cả hai; nếu vượt khả năng đọc trên điện thoại thì thu phạm vi sân hoặc thiết kế chỉ báo ngoài màn hình trước khi mở camera tự do.
- `toWorld` phải đảo đúng camera transform. Hover, telegraph, bóng, đạn, target picking và tap dùng cùng hệ tọa độ; HUD ở ngoài camera. Không chọn điểm bằng vị trí màn hình trước pan rồi dùng với transform sau pan.
- Obstacles/collision chỉ là đợt sau. Đá/trúc trang trí chưa có collision không được làm người chơi tưởng đó là vật chắn đạn. Vật chắn thật phải có hình, hình học, luật đạn và AI tìm đường thống nhất.

## 3. AI chung: chọn hành động theo tình huống

Tách ba phần: **quan sát → sinh hành động hợp lệ → chấm điểm và cam kết hành động**. Mỗi nhịp nghĩ, lấy snapshot quan sát được, gọi check của sim để lọc lệnh, chọn hành động có điểm tốt nhất; log lý do để review.

| Nhóm hành động | Tiêu chí |
|---|---|
| Né/thoát nguy hiểm | Telegraph/đạn đã xuất hiện, thời gian tới hit, đường thoát hợp lệ, chi phí bỏ chiêu đang vận |
| Ra đòn | Có tầm, hướng, độ sâu và khả năng trúng; ưu tiên lúc đối thủ thu chiêu hoặc đã tự khóa vị trí |
| Áp sát/giữ khoảng cách | Tầm hiệu quả của bộ cổ thực có, chi phí chân nguyên, nguy cơ bị dồn biên, đường đi |
| Hộ thể/hồi phục | Nguy hiểm dự kiến trong cửa sổ buff, thời gian vận, phí duy trì, có đủ khoảng trống để thực hiện |
| Chờ/đổi vị trí | Thiếu chân nguyên, chưa có cơ hội; chờ không có nghĩa đứng im ăn đòn |

- Các thuộc tính dự kiến của skill: vai trò, tầm hiệu quả, dạng đường bay/vùng, windup, recovery, mobility, chi phí và upkeep. Mô tả AI đọc dữ liệu gameplay, không suy ra năng lực chỉ từ clip `cast` hay tên nhân vật.
- AI chỉ dùng động tác/telegraph/vị trí nhìn thấy. Không đọc con trỏ, lệnh chưa phát, trạng thái tương lai hoặc seed RNG. Thông tin cooldown/tài nguyên địch nếu game không công khai phải dùng ước lượng từ hành động đã quan sát; tài nguyên của chính nó dùng số thật.
- Điểm nhắm được chọn lúc quyết định theo luật chiêu. Có thể dự đoán từ hướng di chuyển vừa quan sát, nhưng giới hạn độ chính xác theo hồ sơ; không bẻ đạn/homing nếu skill không có cơ chế đó.
- Có thời gian phản ứng và jitter. Nhận ra cùng một telegraph một lần, giữ đích né; không cứ mỗi tick đổi bên hoặc hủy vận. Chỉ hủy khi nguy cơ mới vượt lợi ích của chiêu đang làm, theo luật cancel hiện có.
- Chống thả diều bằng cắt góc, ép biên, giữ tầm và trừng phạt thời gian vận. Không teleport, tăng tốc bí mật hay cấp chiêu tầm xa cho nhân vật không có.
- Độ khó chủ yếu đổi phản ứng, sai số nhắm, khả năng đọc thời cơ và quản lý tài nguyên. Hệ số damage hiện có cần giữ riêng để benchmark không lẫn thay AI với tăng sức mạnh.

## 4. Hồ sơ chiến thuật theo nhân vật

Các dòng dưới là **đề xuất dàn dựng chiến thuật**, chưa xác nhận mọi bộ cổ của 39 asset. Cổ được phép dùng phải lấy từ data + thời kỳ + nhánh đã đối chiếu; phong cách không cấp thêm năng lực.

| Mẫu hồ sơ | Nhân vật thử | Hành vi đặc trưng |
|---|---|---|
| Áp sát, ép nhịp | BNB theo mốc truyện | Chủ động tranh tầm, chờ/cắt đường né, chiêu lớn khi người chơi bị khóa vận; tính tiền duy trì và phương án thoát thân đúng thời kỳ |
| Tầm trung, đánh có nhịp | Phương Chính | Giữ khoảng cách dùng nguyệt nhận, bảo vệ khi cần, hạn chế đổi chiến thuật quá nhanh; không sao chép mọi lựa chọn tối ưu của BNB |
| Khống chế, bảo vệ | Thanh Thư dạng người | Khai thác roi/kim/đường cong nếu bộ cổ đã có; giữ vùng giao chiến, phản công khi đối thủ áp sát; Mộc Mị là biến thể/sự kiện riêng |
| Lao tới theo đợt | Heo rừng | Lấy đà húc có cảnh báo, cam kết hướng rồi thu chiêu; không quay mục tiêu tức thì trong pha lao |
| Đánh gần, kiểm soát không gian | Hắc Hùng | Đòn nặng chậm, bám vị trí có lợi, tránh chạy ziczac như người dùng phi đạn |
| Cơ động, quấy rối | Điện Lang thường | Đổi góc, lao ngắn rồi thoát; gọi bầy chỉ nếu bộ kỹ năng thật có, không mặc định mọi sói có sét |
| Boss thú | Lôi Quan Lang Vương | Ép người chơi bằng đòn thú và kỹ năng sét đúng bộ; không dùng pose chưởng hoặc mặc định tru gọi bầy từ sprite sói thường |
| Chỉ huy/summoner | Hàn Bất Lưu | Giữ khoảng cách và dùng chó theo cơ chế đã có; nếu sim chưa hỗ trợ summon thì đánh dấu chưa triển khai, không thay bằng đạn phép tùy ý |
| Cận chiến lực đạo | Thiết Bá Tu/Cự Khai Bi/Hoành Mi | Thử khác nhau về truy đuổi, cam kết đòn và chọn phản công; thông số cụ thể phải theo từng kit, không coi cả nhóm cùng bộ cổ |

Hồ sơ gồm `preferredRange`, `aggression`, `commitment`, `resourceReserve`, `defensePriority`, `aimError`, `reaction`, `repositionPolicy`, và trọng số action. Giá trị số chốt sau pilot, không dựng 39 hồ sơ chỉ bằng đổi tên. NPC không chiến đấu và biến thể phải được phân loại riêng.

**Giới hạn hiện tại:** cả sim và input/HUD còn phụ thuộc PN/BNB. Bước đầu hỗ trợ PN đối đầu một actor bất kỳ qua `enemyId/getOpponent`, kit và profile riêng. Chưa coi đây là hỗ trợ nhiều địch; lang triều/summon cần target selection, đội phe, collision, vòng đời actor và điều khiển bổ sung.

## 5. Hiệu ứng có generate được không?

**Có thể thử generate hình/chuỗi pose FX riêng**, rồi nhập thành PNG/atlas. Không bảo đảm một prompt xuất ngay chuỗi frame liên tục, alpha sạch hoặc đúng kích thước. Ưu tiên đồ vật/sinh vật có silhouette quan trọng; code làm đường bay, timing, scale/mirror và mảnh nhỏ. Không yêu cầu máy người dùng render video dài.

| Ưu tiên | Asset generate đề xuất | Phần code giữ quyền điều khiển |
|---|---|---|
| 1 | `fx_cuxi`: rết vàng có đốt/răng; `fx_cuongthu`: bàn tay thép mở → chộp | Đường vung/kéo, tầm hit, contact, hủy/thả; đọc cùng mục 4b prompt roster |
| 2 | Lưỡi nguyệt, lưỡi băng, 3–4 biến thể impact băng/nguyệt/ngọc | Projectile thật, xoay cả vật thể nếu phù hợp, trail, impact tại snapshot hit; không xoay tay/chân actor |
| 3 | Mảnh xoáy băng và sương thoát thân, 4–6 frame nếu thực sự cần đổi hình | Vị trí/radius zone, thứ tự trước/sau actor, thời điểm zoneFire và tắt cảnh báo |
| 4 | Vảy giáp ngọc/vàng, gợn nước và lá hồi phục | Gắn thân/anchor, đổi hộ thể, tắt khi hết phí/thời hạn, âm tương ứng |

### Quy trình asset FX

1. Duyệt một mẫu phong cách ở kích thước battle: pixel sắc, palette ít màu, không blur lớn hoặc quầng sáng che actor. VFX cùng chất liệu có thể dùng chung, nhưng phải giữ dấu hiệu riêng của chiêu.
2. Prompt một FX, không kèm nhân vật/nền cảnh/chữ; ghi hướng, pha và số pose rõ. Chỉ yêu cầu các pha thật cần đổi silhouette, không ép mọi vật thể thành 8 frame.
3. Ưu tiên alpha thật. Nếu nền màu phẳng, chọn màu key không xuất hiện trong FX: tránh xanh lá cho Thanh Đằng/lá và nền trắng cho băng. Kiểm fringe và vùng bị xóa nhầm.
4. Nhập qua **pipeline FX riêng**; không dùng tự động đo mặt/căn chân của `keypose_import.py` cho hiệu ứng. Manifest đề xuất: frame rect, pivot, anchor-role, timing, hướng gốc, palette/material, source và tình trạng duyệt. Sheet phải ghép từ frame đã kiểm, không tin grid AI vẽ.
5. Registry ánh xạ skill/phase → FX và cue. Các event act/release/interrupt/impact/expire cần ID vòng đời; dọn startup bị hủy, shield cạn chân nguyên, restart và end battle. Asset không tự sinh damage hoặc callback quyết định gameplay.
6. Giữ telegraph có độ tương phản cao dưới FX, chữ sát thương và mục tiêu vẫn đọc được. Chọn chế độ giảm FX cho điện thoại; đề xuất pool sau khi đo số hiệu ứng đồng thời, chưa thêm chỉ vì có roster.

Đợt pilot chỉ tạo rết, bàn tay và impact băng. Nghe A/B âm cùng hình, kiểm âm lượng nhiều cue; không trì hoãn mọi phần để chờ đủ FX 39 nhân vật.

## 6. Khi nhận bộ asset 39 nhân vật

- Đối chiếu số **id thực tế**, variants và NPC; danh sách prompt cũ không đủ để khẳng định có đúng 39 nhân vật chiến đấu.
- Lập bảng mỗi id: thời kỳ, base/identity, clip có/thiếu, số pose, pivot, kích thước, anchor tay/vũ khí/mõm, trạng thái duyệt và kỹ năng có thể biểu diễn.
- Kiểm alpha/nền xanh, tràn frame, sai scale giữa clip, chiều mặt, anatomy, trang phục/giới tính và biến thể. Không tự đổi bản đã duyệt bằng file version mới nhất.
- Ghép contact sheet và preview diễn cả bộ ở kích thước thật; kiểm silhouette khi dùng skill thật. Asset đẹp không chứng minh skill đúng cốt truyện hoặc animation đã mượt.
- Review gameplay và identity có căn cứ; màu áo/phụ kiện mỹ thuật ghi là thiết kế khi chưa có nguồn. Chưa có clip riêng thì báo fallback đang dùng, không gán chưởng cho mọi skill.
- Sau review mới chọn pilot roster: BNB, Phương Chính, Heo rừng hoặc Điện Lang. Thanh Thư/summoner triển khai sau khi loại đường roi/đạn/summon tương ứng hoạt động.

## 7. Thứ tự triển khai và kiểm chứng

| Bước | Bàn giao review | Điều kiện đi tiếp |
|---|---|---|
| R-01 | Kiểm kê asset + baseline sim/benchmark hiện tại | Không thiếu file/clip bắt buộc, ghi rõ Thiên Bồng mới; giữ seed và chính sách bot |
| R-02 | Cấu hình sân 1v1, phép chiếu/input, thử sân A | Bounds/spawn hợp lệ, round-trip toWorld đúng, KO mọi góc không cắt, mobile vẫn đọc actor |
| R-03 | AI chung + BNB pilot | Phản ứng sau tín hiệu, đủ tài nguyên khi phát, không tự hủy liên tục hoặc kẹt biên |
| R-04 | Hai profile đối lập: caster và thú lao | Cách đánh nhìn khác nhau, không có chiêu trái kit/thời kỳ; vẫn giữ inventory PN |
| R-05 | Ba FX pilot, event/anchor và audio | Trúng/trượt/hủy phân biệt, không lệch hitbox, không sót FX/voice sau restart/kết trận |
| R-06 | Nhân rộng roster đã duyệt, campaign adapter | Save/nhánh và skill sở hữu đúng; không bật cả roster chưa kiểm |

Đo A/B riêng: **sân cũ/AI cũ → sân mới/AI cũ → sân mới/AI mới** với cùng kit, difficulty multiplier, seeds và chính sách chơi. Không đổi map, tài nguyên, HP và AI một lượt rồi quy mọi cải thiện cho AI.

Benchmark đề xuất 3 seed × 300 trận cho stand/spam/move ở mức Thường; thêm Khó sau pilot. Ghi tỷ lệ thắng, thời gian, timeout, quãng đường, thời gian đứng/chạy, damage nguồn, số hủy startup, số chiêu trượt, cạn chân nguyên và thời gian kẹt biên. Đây là đo bot, không thay chơi thử người thật.

Kiểm hành vi có mục đích: né cảnh báo sau reaction; giữ hướng húc trong active; không heal cạnh đòn đã báo; không dùng shield khi tiền duy trì không đủ; không nhìn input bí mật; không hủy hàng trăm lần; caster không vô hạn chạy vòng khiến trận timeout. Test một actor có id khác BNB để bắt các chỗ còn hard-code.

Kiểm view/input trên chuột và giả lập cảm ứng, rồi điện thoại thật: tap đi/đánh, điểm nhắm, Dừng, HUD không chắn sân, vật thể lớn ở depth gần. Đo frame time/FX trên thiết bị được ghi rõ; không tuyên bố đạt mobile chỉ từ Chrome desktop.

## 8. Nhờ Orange-kun review

1. Có đồng ý thử sân nhìn toàn bộ 1400×320 trước camera? Chốt cùng cách đánh giá tốc độ di chuyển trên màn hình và tầm chiêu.
2. Rà các hard-code PN/BNB và hằng số toàn cục trước refactor; đề nghị API cấu hình một trận nhưng giữ baseline PN–BNB hoạt động.
3. Review AI chấm điểm + commitment, thông tin được quan sát và cách khó lên mà không gian lận. Chốt BNB pilot trước khi viết profile hàng loạt.
4. Khi có asset mới, xác nhận danh sách id/thời kỳ/clip để chọn hai pilot có phong cách đối lập. Không giả định 39 asset đồng nghĩa 39 kit hoàn chỉnh.
5. Đồng ý ưu tiên generate rết/bàn tay/impact băng và pipeline FX riêng? Ghi phản hồi về event/anchor/âm trước nhập asset.
6. Phối hợp kế hoạch chân nguyên đang chờ review: AI dùng chung quy tắc chi phí của sim; giảm khóa 2s không nằm trong lượt mở sân/AI này.

## 9. Review của Orange-kun (02/10/2026)

### 9.1. Sân lớn: đo trước, kết quả đáng lo

Thử nhanh bằng bản sim chép ra scratchpad (chỉ đổi X1/Z1, spawn đặt giữa sân cách nhau 380 như cũ, kit/AI/seed giữ nguyên, Thường, seed 20261002, 300 trận). Runtime không đổi.

| Sân (world) | stand | spam | move | thời gian move |
|---|---:|---:|---:|---:|
| 1000×240 (hiện tại) | 10,7% | 1,7% | 84,7% | 43,8s |
| 1400×240 | 10,7% | 2,3% | **96,3%** | 44,5s |
| 1400×320 | 10,7% | 2,3% | 94,7% | 43,6s |

Sân rộng thì **thả diều mạnh hơn hẳn** (bot né đã thắng 85%, lên 96%). Chiều sâu 240 → 320 gần như không đổi gì. Vì vậy:

1. **Đồng ý thử sân A (toàn sân, không camera)**, nhưng R-02 và R-03 phải đi cùng nhau, hoặc làm AI chống thả diều trước. Nếu mở sân trước khi AI biết cắt góc và ép biên thì người chơi chỉ cần chạy vòng bắn Nguyệt Mang.
2. Đo kích thước sân bằng **thời gian chạy**, đừng đo bằng số world. Hiện PN chạy hết sân 780 trong khoảng 2,9s và tầm Nguyệt Mang 560 bằng 72% sân. Ở 1400, chạy hết sân mất 4,5s và tầm chỉ còn 47%. Đề xuất mục tiêu ban đầu 1200×260: chạy hết khoảng 3,8s. Bậc 1400 thử sau.
3. Tốc độ: **giữ tốc độ world, chấp nhận tốc độ trên màn hình giảm** (vì 1400 world vẫn chiếu vào 960 px). Sprite giữ cỡ pixel cũ nên trông to hơn so với sân. Nếu thấy bước đi chậm hoặc chật thì chuyển sang camera B. Không tăng speed toàn bộ, vì làm vậy sẽ đổi cân bằng tầm/né.
4. Phép chiếu cho sân mới nên dùng cùng công thức padding Orange-kun đề xuất cho KO (`sx = OX + x·KX`, lề ≥ bề vươn sprite lớn nhất + 2 px; xem `KE_HOACH_CHOT_SANDBOX_PN_BNB.md` §8). `worldRect` / `playableBounds` của blue-chan khớp với hướng này: lề là của view, sim chỉ biết `playableBounds`.

### 9.2. Hard-code cần gỡ trước refactor (đã grep)

Số lần tham chiếu `SBSim.X0/X1/Z1` hoặc `'pn'/'bnb'/actors.pn/actors.bnb`: `input.js` 15, `view.js` 12, `sim.js` 6, `hud.js` 5, `audio.js` 2, `ai.js` 1, `battle_sandbox.html` 1. Đề xuất API:

- `SBSim.create(kits,{arena:{bounds,spawns}, ids:{player,enemy}})`. `B.arena` thay hằng toàn cục, và view/input/AI đọc `B.arena`. Mặc định giữ đúng 110/890/240 để bench cũ chạy y nguyên.
- `other(B,a)` → `B.opponentOf(a)`. Nếu 1v1 thì trả actor còn lại theo `ids`. Không đặt cứng id `'bnb'` trong AI/HUD/audio (`audio.js` đang so `e.who==='bnb'` để chọn âm băng; nên chọn theo `kit.material` hoặc cue của skill).
- Test hồi quy thêm một ca với id địch khác `bnb` (đúng như mục 7 đề xuất).

### 9.3. AI chấm điểm: đồng ý, kèm hai lưu ý

- **AI hiện đang đọc thông tin ẩn**: `ai.js` né Nguyệt Mang dựa vào `ta.aim.z`, tức điểm con trỏ người chơi nhắm. View không vẽ điểm nhắm này. Như vậy là vi phạm luật “chỉ dùng thứ nhìn thấy” ngay trong code hiện tại. Sửa một trong hai cách: (a) vẽ hướng/vệt nhắm lúc PN lấy đà Nguyệt Mang (cũng giúp người chơi đọc đòn khi chơi PvP sau này), hoặc (b) AI chỉ dùng hướng mặt + z hiện tại của PN để ước lượng. Orange-kun nghiêng về (a).
- Đừng làm utility AI quá “thông minh” rồi mới thêm sai số. Dựng bộ khung quan sát → lọc bằng `check` → chấm điểm, rồi **cho mỗi hồ sơ một số ít trọng số**. Độ khó đổi `reaction`, `aimError`, `commitment`; hệ số sát thương giữ riêng như blue-chan nói. BNB pilot phải tái hiện được hành vi hiện tại trước, rồi mới thêm cắt góc. Như vậy mới so được với bench cũ.
- Thêm vào hồ sơ: `kiteCounter` (cắt góc, ép biên, lướt áp sát khi người chơi đang lùi). Đây là thứ thiếu nhất theo số đo ở 9.1.

### 9.4. Hồ sơ nhân vật (mục 4)

Đồng ý cách tách “phong cách” khỏi “năng lực”. Bảng hiện tại đúng tinh thần. Lưu ý thêm:

- Lôi Quan Lang Vương / Điện Lang: prompt roster đã ghi `dien_lang` khác `loi_quan_lang` (tru vs sét). Profile phải theo đúng id đó.
- Hàn Bất Lưu: summon cần nhiều actor, nên đẩy ra sau R-06 như blue-chan ghi. Đồng ý.
- Pilot đối lập: đề xuất **Phương Chính (caster tầm trung)** + **Heo rừng (lao theo đợt)**. Hai kiểu này dùng được ngay các `kind` sim đã có (`proj`, `melee` + `dash` có hướng cam kết) nên ít phải thêm cơ chế mới.

### 9.5. FX generate

- Đồng ý: ưu tiên rết / bàn tay / impact băng, và pipeline FX **riêng** (không dùng `keypose_import.py` vì nó đo mặt/căn chân). Prompt rết/tay đã có ở `PROMPT_MUSE_ROSTER.md` §4b, dùng lại.
- Màu key: đề xuất **magenta #FF00FF** cho mọi FX (an toàn với lá/xanh Thanh Đằng, băng trắng và vàng rết). Nếu Muse trả alpha thật thì ưu tiên alpha.
- Manifest FX đề xuất ở mục 5.4 là đủ. Thêm `blend` (normal/add) và `loopFrames` cho xoáy băng.
- Registry cần `hid` trên event `act`/`release`. Hiện `act` vẫn chưa có `hid` (đã ghi ở VFX §13).

### 9.6. Thứ tự đề xuất sửa lại

R-01 → **R-03a** (AI khung + BNB tái hiện hành vi cũ + kiteCounter, gỡ đọc `aim`) → R-02 (sân 1200×260 + `B.arena`) → R-03b (đo sân mới với AI mới) → R-04 → R-05 → R-06. Đo A/B ba bước như mục 7 vẫn giữ, chỉ đổi thứ tự để không bao giờ có bản sân rộng + AI cũ được coi là baseline chơi thử.

### 9.7. Cần người dùng quyết định

- Sân rộng: nhìn toàn sân (nhân vật giữ cỡ, bước đi trên màn hình trông chậm hơn khoảng 30% ở sân 1400), hay muốn camera đi theo (giữ nhân vật to, phải có chỉ báo khi đối thủ ra ngoài màn hình)?
