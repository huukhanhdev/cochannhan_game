# Sân 1200×260 và AI ép nhịp — Blue-chan bàn giao Orange-kun

02/10/2026. Đã triển khai bước thử sân + BNB pilot sau người dùng chốt nhìn toàn màn. Chưa tạo roster/FX mới, chưa nối campaign. Nền trúc đang có được tái sử dụng nguyên ảnh, không gọi đây là map mỹ thuật mới đã duyệt.

## 1. Preview và cấu hình

- Mặc định `battle_sandbox.html`: sân 1200×260, playable x=110…1090, AI `pressure` (Ép nhịp). Giữ viewport 960×430, kích thước sprite, kit, HP, damage, phí, cooldown và tốc độ world.
- Có dropdown Sân và AI. URL đối chứng: `?arena=classic&ai=legacy`; bản thử: `?arena=wide&ai=pressure`. Classic vẫn world 1000, x=110…890, z=240.
- `SBSim.create()` mặc định vẫn classic để test/caller cũ không tự mở rộng. Cấu hình từng trận ở `B.arena`, preset dùng chung `SBSim.ARENAS`; validate biên/số hữu hạn. Khoảng cách spawn vẫn 380 world, đặt quanh giữa sân.
- Thêm `B.ids` và `B.opponentOf()`, gỡ cặp id cứng trong sim/input/HUD/view/AI. Audio impact dùng `skill.fx` thay vì tên BNB. Đã test sim với `hero/rival`; chưa coi đây là hoàn tất hỗ trợ roster hoặc nhiều địch.

## 2. Phép chiếu và margin

- Sàn chiếu cùng khoảng y=250…400; z lấy từ arena đang chạy. `ground_screen_y` lỗi về baseline, không chia cho 0.
- `KX=(960−2×127)/(X1−X0)`, `OX=127−X0×KX`, `sx=OX+x×KX`; `toWorld` đảo đúng công thức. Range/guide/AoE/cung rết cùng dùng KX, không chỉ dịch actor.
- Không thu biên sim để giấu clipping. Đo alpha ≥100 mọi frame/clip: PN vươn tối đa 123,47px; BNB 124,66px ở scale gần nhất. Lề 127px dư lần lượt 3,53/2,34px. Kết quả chỉ bảo đảm hai asset hiện tại; thú/FX rộng phải đo riêng.
- Tốc độ world giữ nguyên; đi ngang nhìn chậm hơn khi trải 980 world vào 706px. Với PN speed 265, vượt biên sân rộng mất khoảng 3,70s so với 2,94s sân classic, bỏ qua slow/va chạm.

## 3. Telegraph và AI

- Projectile có snapshot `telegraph` từ lúc nhận lệnh: vị trí, hướng đã khóa, range và visibleAt. View vẽ hướng trên sàn và từ tay trong startup, tắt khi release/hủy. Điểm nhắm touch còn đang chọn chưa được công khai hoặc đưa cho AI.
- AI né đạn đọc ray công khai, kiểm hướng/độ lệch và chờ ít nhất 0,15s; không đọc `act.aim`. Event act/release thêm hid cho vòng đời FX sau này.
- BNB pilot ghi quan sát vị trí ở nhịp nghĩ; suy vận tốc từ hai mẫu, giới hạn theo tốc độ đi. Không đọc đích move, con trỏ hoặc tương lai.
- Nhóm ứng viên: cắt góc khi địch lùi, áp sát khi thấy vận buff/heal/đạn, ép biên. Ghi `actor.decision` gồm role/thời điểm/đích để debug. Lướt dùng khi check hợp lệ, không tăng speed hoặc teleport; state bận giữ nguyên.
- Mức Thường Ép nhịp nghĩ 0,28s + jitter tối đa 0,1s; đối chứng giữ 0,4s + 0,15s. Thường có xác suất né melee/grab startup đã lộ ≥0,2s; Khó giữ khả năng né đó. Không tăng damage multiplier trong lượt này.
- AI mới không đặt Lốc lên actor đang move; còn hạn chế chọn thời điểm tốt hơn. Đây là **BNB pilot bổ sung nhóm ứng viên**, chưa phải utility AI đầy đủ cho mọi kit.

**Lưu ý đối chứng:** `legacy` giữ chính sách trước nhóm ép nhịp, nhưng cũng được sửa đọc aim ẩn thành telegraph công khai và thêm trễ phản ứng. Vì vậy không gọi nó là bản AI cũ giống byte-for-byte. Báo cáo cũ Orange đo dùng phiên bản khác, không ghép tỷ lệ hai báo cáo làm cùng một thí nghiệm.

## 4. Benchmark bản cuối

Thường, cùng kit/damage/speed, ba seed 20261002/42/9001, mỗi seed 300 trận mỗi chính sách. Báo cáo: [sandbox_arena_ai_2026_10_02.json](../../tools/reports/sandbox_arena_ai_2026_10_02.json).

| Sân / AI | PN đứng yên thắng | PN spam thắng | PN né/phản công thắng |
|---|---:|---:|---:|
| Classic / đối chứng | 10,7–12,7% | 1,7–4,3% | 81,7–84,3% |
| Wide / đối chứng | 10,7–12,7% | 2,3–3,3% | 86,7–91,7% |
| Classic / Ép nhịp | 4,0–5,0% | 5,0–5,7% | 75,3–81,0% |
| Wide / Ép nhịp | 4,0–5,0% | 2,3–3,0% | 84,7–88,3% |

Không timeout trong các lượt trên. Wide/Ép nhịp bot né đánh khoảng 41,9–42,7s. Hiệu quả chống thả diều **có nhưng còn nhỏ**; sân rộng vẫn giúp né so với classic. Không ép tỷ lệ về 50% bằng tăng damage/HP. Cần người thật thử nhịp nghĩ mới, chất lượng ray và tốc độ đi nhìn trên mobile. Chưa đo lại Khó trong lượt này.

Đo lại một cấu hình:

```bash
node tools/sandbox_bench.cjs 300 thuong compare 20261002 wide pressure
node tools/sandbox_bench.cjs 300 thuong compare 20261002 classic legacy
```

## 5. Kiểm tra

- Sandbox regression: các nhóm cũ, arena/id riêng, clamp movement, phí release, AI không đọc getter aim/đích move ẩn và cắt góc từ quan sát đều đạt.
- Input regression, kiểm dữ liệu và engine regression đạt; cú pháp các file thay đổi qua.
- Chrome desktop và viewport mobile 390px: tải không lỗi, tap chọn Nguyệt/commit/Dừng qua, không tràn ngang; hai mép hiển thị x=127/833 đảo về đúng x=110/1090. Chưa thử điện thoại thật.
- Preview ảnh ở `previews/arena-ai-v01/`: desktop, mobile và telegraph. Browser test `tools/sandbox_browser_regression.cjs` cần server 8765, Puppeteer và Chrome local.

## 6. Orange cần review tiếp

1. Kiểm sx/toWorld/tầm/va chạm hình và tốc độ cảm nhận; kiểm thêm ảnh KO ở bốn góc trên thiết bị.
2. Telegraph hướng công khai có quá rối không? Cùng ray dưới chân và từ tay cần duyệt hình; không bỏ ray mà vẫn cho AI đọc hướng chính xác.
3. Review tránh zigzag, phí/nhịp lướt, luật né Thường và nhóm ứng viên. Test người thật trước chỉnh thêm thông số.
4. Khi nhận asset mới, chọn Phương Chính/Heo rừng cho pilot kế tiếp, thêm kit/profile theo thời kỳ thực; hiện chưa tạo hai kit này.
5. FX rết/bàn tay/impact băng và pipeline nhập riêng vẫn là bước tiếp theo, chưa generate hoặc nghiệm thu trong lượt sân/AI này.
