# Kế hoạch cân bằng cổ trùng và BNB theo mốc truyện

Kế hoạch bổ sung theo yêu cầu hạn chế spam bằng tài nguyên: [Chân nguyên và nhịp dùng cổ](KE_HOACH_CHAN_NGUYEN_VA_NHIP_DUNG_CO.md). Theo review Orange-kun: ưu tiên phí cổ, dung lượng bể và phí Băng nhận; đo nguồn hồi cùng ngân sách trước khi thử giảm khóa chung 2s.

**Cập nhật triển khai 02/10/2026:** riêng thông số Thiên Bồng ở mục 5.1 đã áp vào sandbox theo yêu cầu người dùng; xem [ghi chú bàn giao](NOTE_APPLY_THIEN_BONG_3S.md). Các phần kế hoạch khác bên dưới chưa được coi là đã triển khai.

02/10/2026 — Blue-chan, gửi Orange-kun review. **Bản kế hoạch, chưa thay code hoặc thông số trận.** Yêu cầu: gặp BNB lần đầu có thể thắng trong nhánh VN nhưng rất khó; PN về sau mạnh lên nhờ tiến cảnh và bộ cổ đúng thời điểm. Di chuyển, chọn thời điểm vận cổ và quản lý chân nguyên phải có giá trị.

## 1. Đối chiếu truyện: những điểm phải sửa

Đối chiếu trực tiếp bản dịch chương truyện, không lấy bảng tóm tắt trong repo làm bằng chứng cuối cùng. Link dưới dẫn tới nội dung chương; tên Việt cần Orange-kun so lại với bản dịch đang dùng.

| Mốc | Điều đã xác minh | Hệ quả cho game |
|---|---|---|
| Ch.129 | PN phát hiện Cự Xỉ Kim Ngô hoang dã nhưng hoãn thu phục. Có tên chương không đồng nghĩa đã sở hữu cổ. | Không mở Cự Xỉ chỉ vì đã tới ch.129. [Chương 129](https://novelfull.com/reverend-insanity/chapter-129.html). |
| Ch.133–138 | PN đã gặp và giao đấu với BNB trước đoạn huyết hải. BNB tự áp chế nhị chuyển (ch.134); Lam Điểu Băng Quan đã dùng ở ch.136, Sương Yêu là cổ tam chuyển tăng công (ch.137). Cuộc truy đuổi có tiểu tổ Hùng Lực (ch.135–136) và người đuổi giết (ch.138), không phải PN thắng một BNB hoàn toàn khỏe bằng đấu đơn thuần. | Tách nhánh chủ động thách đấu lúc mới gặp khỏi tình huống BNB đã hao tổn. [Chương 134](https://www.webnovel.com/book/7996858406002505/25307329046038953), [chương 139 hồi thuật tình trạng BNB](https://www.wuxiaworld.eu/chapter/reverend-insanity-139). |
| Ch.139 | BNB tự nổ **tay phải** bằng Frost Demon Gu/Sương Yêu để thoát tình thế bị vây, tạo băng bảo vệ và hồi phục. Việc này xảy ra trước trận Thanh Thư đánh BNB. | Lúc mới gặp vẫn đủ hai tay. Sương Yêu không phải một cú lướt miễn phí được làm mới mỗi trận. [Chương 139](https://www.wuxiaworld.eu/chapter/reverend-insanity-139). |
| Ch.143 | Khi Thanh Thư biến thành cây và giữ BNB, PN dùng Cường Thủ/Plunder Gu đoạt lần lượt **Xích Thiết Xá Lợi, Thạch Khiếu và Thủy Tráo**. BNB được cứu, vẫn sống. | Thủy Tráo phải rời bộ cổ BNB sau sự kiện đoạt cổ; không tự cấp lại ở trận sau. **Thạch Khiếu đã xác nhận theo đối chiếu bản Việt của Orange-kun, mục 10.2.** [Chương 143](https://novelfull.com/reverend-insanity/chapter-143.html). |
| Ch.155 | PN hợp luyện Thiên Bồng tam chuyển. Lần đầu Bạch Ngọc + Thủy Tráo thất bại, Thủy Tráo chết; lần sau dùng cổ phòng ngự nước đổi bằng chiến công và Bạch Ngọc thì thành công. Cổ được gia tộc cấp là **Lôi Dực**, không phải Thiên Bồng. | Không có Thiên Bồng ở lần gặp đầu. Sau hợp luyện không giữ thêm bản Bạch Ngọc cũ để luân phiên hộ thể, trừ khi nhánh VN thực sự kiếm bản khác. [Chương 155](https://www.pyg-kit.com/en/books/reverend-insanity/chapters/78109). |
| Ch.166 | Tên chương là **lần giao đấu thứ hai**. PN dùng Thiên Bồng, Cự Xỉ, Lôi Dực và nguyệt nhận màu máu. BNB một tay có phòng ngự cơ băng, Blue Bird Ice Coffin và **Icicle Gu/Băng Trùy**. | Băng Trùy có ở Q1 muộn. Nhận định cũ của Blue-chan rằng nên bỏ khỏi toàn Q1 là quá rộng, cần sửa. PN đã có khả năng áp đảo cận chiến trước đoạn cưỡi nhện lên mặt đất. [Chương 166](https://www.wuxiaworld.eu/chapter/reverend-insanity-166). |
| Ch.173 | Bạch Tướng Tiên Xà là cổ **ngũ chuyển**, xuất hiện từ linh tuyền Bạch gia và vào không khiếu BNB. | Chỉ đưa vào giai đoạn muộn; tên có chữ “tiên” không biến nó thành cổ lục chuyển. [Chương 173](https://www.wuxiaworld.eu/chapter/reverend-insanity-173). |
| Ch.190 | Đây là **lần giao đấu thứ ba**, lúc PN lên bằng Thousand Li Earthwolf Spider. Rắn trắng chưa được BNB luyện hóa, bị thể chất Bắc Minh Băng Phách thu hút; sau va chạm với nhện nó phun sương rồi bỏ đi. | Rắn là tác nhân tự chủ của màn, không phải nút đại chiêu ngũ chuyển BNB có thể spam. Nhện cũng không mặc định là thú cưỡi chiến đấu hoàn toàn nghe lệnh. [Chương 190](https://www.pyg-kit.com/en/books/reverend-insanity/chapters/78144). |

Ba gia tộc trên Thanh Mao Sơn là **Cổ Nguyệt, Bạch, Hùng**; Xích và Mạc là phe nội bộ Cổ Nguyệt. Không gọi hội ba nhà là “Xích–Mạc–Cổ Nguyệt”. Chương 173 nêu rõ ba gia tộc và linh tuyền của họ ở đoạn đối thoại đầu. Tên nhện trong bản Anh là Thousand Li Earthwolf Spider; cần đối chiếu tên Việt Thiên Lý Địa Lang Chu, tránh dùng “Thiên Địa Lang” cho một con sói.

**Phân biệt hai điều:** người dùng nhớ đúng việc PN chưa có Thiên Bồng khi mới gặp BNB và đoạt cổ trong trận Thanh Thư. Nhưng PN không chỉ giao đấu sau khi từ huyết hải đi lên; có thêm trận ch.166 ở giữa. BNB mất tay không đồng nghĩa mọi trận sau đều yếu: hắn thôi áp chế tu vi, có thêm phương thức đánh và về sau có rắn trắng.

## 2. Sai lệch hiện tại và nguyên nhân Thiên Bồng dễ thắng

Đã đọc `js/sandbox/kits.js`, `sim.js`, và nhánh `c_bai` trong `js/events.js`:

- Sandbox nạp một bộ cố định: PN 220 HP; BNB 300 HP. PN có 8 action: đánh tay, Nguyệt Mang, Bạch Ngọc, Cự Xỉ, Cường Thủ, Thiên Bồng, lướt, Sinh Mệnh Diệp. BNB có 5 action: Băng nhận, Lốc băng nhận, Thủy Tráo, Sương Yêu, lướt. Đây là số action, không phải số cổ sở hữu.
- Bộ đó trộn nhiều giai đoạn: PN vừa có Bạch Ngọc vừa có Thiên Bồng; BNB còn Thủy Tráo và Sương Yêu bất kể đã mất cổ/tay. BNB cũng thiếu Lam Điểu đã có từ ch.136 và Băng Trùy xác minh ở ch.166.
- `c_bai` đã cho lựa chọn quyết chiến ngay lần gặp; sau sự kiện mới lên lịch `c_kimngo` nếu chưa sở hữu. Sandbox chưa tự lấy bộ cổ từ trạng thái VN. Phải sửa cả đường nối encounter, không chỉ thay kit demo rồi coi campaign đã đúng.
- Thiên Bồng hiện vận 0,40s, giảm 65% sát thương trong 5s, tốn 18 chân nguyên một lần, CD 14s. Hộ thể không tốn duy trì, vẫn cho di chuyển và ra chiêu sau recovery. Đánh thường BNB 24 còn khoảng 8; Lốc 96 còn khoảng 34 khi không có xuyên giáp.
- `a.shield` chỉ có một ô nên không cộng dồn hai giáp; **luân phiên** Bạch Ngọc/Thiên Bồng vẫn là vấn đề. CD chung 2s ngăn kích hoạt dồn, không ngăn hộ thể đã bật tồn tại trong lúc tung đòn khác.
- Tester báo mở Thiên Bồng thắng chế độ thường: ghi nhận là phản hồi người chơi, chưa chứng minh mọi chiến thuật đều thắng 100%. Cần tái hiện thao tác đó sau khi sửa đúng kit.

Ưu tiên sửa sai thời điểm trước. Không tăng máu boss để bù cho việc PN đang được dùng cổ chưa có. Sandbox `red` là tỷ lệ **giảm** sát thương; một số bảng battle cũ dùng hệ số sát thương **còn lại**. Khi đồng bộ phải kiểm tra công thức, không sao chép số giữa hai hệ.

## 3. Tách hồ sơ trận theo tiến trình

### 3.1. Ba màn game người dùng đang nói tới

Thống nhất cách gọi **màn game**, không thay cách đánh số của chương truyện:

1. Màn 1: lần đầu gặp BNB (`c_bai`), cho chọn chủ động đánh hoặc rút lui.
2. Màn 2: Thanh Thư đối đầu BNB (`c_lang2`), cho chọn giúp/cứu Thanh Thư. Code hiện có “Xông lên cùng Thanh Thư” và “Giữ tay Thanh Thư”; lựa chọn sau cần quan sát (`soi_tt`) và quan hệ ít nhất 30. Thắng nhánh cứu thì Thanh Thư sống và BNB rút lui; đây là nhánh VN khác truyện.
3. Màn 3: đoạn PN cưỡi nhện lên mặt đất, đối đầu BNB và rắn trắng ở ch.190.

Truyện còn cuộc PN–BNB ch.166 giữa màn 2 và màn 3. Khi chỉ giữ ba màn trên, phải ghi rõ trận ch.166 chưa được biểu diễn thành một màn riêng; không gộp bộ cổ tam chuyển của nó ngược vào màn Thanh Thư. Chưa tự xóa/gộp sự kiện ch.166 trong code ở lượt lập kế hoạch này.

### 3.2. Hồ sơ bộ cổ chỉ dành cho boss; PN đọc inventory người chơi

**Chốt theo người dùng:** encounter chỉ cấu hình bộ cổ của boss. PN không nhận bộ cổ cố định, không bị lọc theo danh sách cổ của một chương hoặc một màn. Khi vào trận, tạo action từ cổ thực sự sở hữu trong save (hiện dùng `S.gu`), tu vi/tài nguyên thực tế và vật phẩm còn lại. Người chơi có gì hợp lệ thì dùng đó, kể cả kiếm sớm hoặc khác tuyến gốc qua nhánh VN.

Mốc truyện dùng để kiểm tra logic **sự kiện nhận, mất, hợp luyện**; không dùng để cấm cổ đã sở hữu khi bắt đầu encounter. Battle không tự cấp Thiên Bồng cho PN, cũng không tước Thiên Bồng nếu người chơi đã hợp luyện hợp lệ trước đó. Cổ chưa có adapter battle phải báo rõ chưa hỗ trợ và bổ sung adapter, không lặng lẽ loại vì không nằm trong bộ mẫu. Giữ lựa chọn trang bị hiện có của người chơi nếu game có cơ chế đó, không thêm giới hạn slot ở kế hoạch này.

| Hồ sơ đề xuất | PN | BNB | Mục tiêu |
|---|---|---|---|
| `bnb_first_meeting` | Đọc inventory/save thực tế, không cấp hoặc cấm cổ theo màn. | Đủ hai tay, bộ cổ trước khi bị đoạt. **Áp chế nhị chuyển đã xác minh ch.134**; Băng nhận, Thủy Tráo, Sương Yêu tăng công và Lam Điểu Băng Quan. Cổ tam chuyển vận bằng chân nguyên nhị chuyển có phí cao; không coi Lam Điểu chỉ xuất hiện muộn. | Đấu đơn chủ động rất khó nhưng có cửa thắng nhờ đọc đòn, né, tiết kiệm chân nguyên. |
| `bnb_exhausted_pursuit` | Đọc inventory/save thực tế, không thay bằng bộ mẫu. | Đã hao tổn sau giao đấu với tiểu tổ Hùng Lực và truy đuổi; đủ tay cho tới sự kiện ch.139. | Nếu làm nhánh này, thắng nhờ thời cơ và địa hình, không lấy làm chuẩn sức mạnh boss khỏe. |
| `bnb_qingshu_rescue` | Đọc inventory/save thực tế. Hỗ trợ Thanh Thư có tác dụng giữ chân, mở sơ hở hoặc gánh đòn. | Trong đoạn ch.139–143 chuyển từ hai tay sang một tay khi nổ Sương Yêu; Thanh Thư và Phương Chính có mặt ở ch.139. Thôi áp chế và dùng bạch ngân từ ch.140; Lam Điểu vẫn có. Ở pha sau tự bạo đã mất tay phải; nếu nhánh VN thay đổi sự kiện tự nổ tay thì đọc trạng thái thực tế. Thủy Tráo còn trước khi bị đoạt, mất sau khi đoạt. | Cho phép cứu Thanh Thư; thắng không tự cấp các cổ PN chưa đoạt. |
| `bnb_second_battle` | Đọc inventory/save thực tế; không tự cấp các cổ PN dùng ở ch.166 cho người chơi chưa có. | Một tay; Băng nhận, Băng Trùy, Blue Bird Ice Coffin; cơ băng làm cơ sở phòng ngự. Không cấp lại Thủy Tráo/Sương Yêu đã mất theo tuyến gốc. | BNB biết đổi cận chiến sang đánh xa; PN mạnh theo tiến trình người chơi. |
| `bnb_third_battle` | Đọc inventory/save thực tế và trạng thái nhánh. | Một tay, bộ muộn; rắn trắng là sự kiện riêng. | Giao đấu/thoát vây trong biến cố, có tác nhân rắn–nhện và sương. Làm sau khi đấu đơn ổn. |

Đây là danh sách nền cho boss, chưa phải toàn bộ cổ đã xác minh. Orange-kun cần lập hai bảng: `boss → encounter/trạng thái → cổ sở hữu` và `cổ PN → sự kiện nhận/hợp luyện/mất → adapter battle`. Bảng PN không có whitelist theo encounter. Đối chiếu từng ID Việt trước khi gen thêm clip. Không mở cổ chỉ bằng số chương hoặc turn. Chọn “thường/khó” thay AI và độ dung sai, không thay inventory người chơi.

Nhánh VN thắng sớm được phép khác truyện, nhưng phải ghi hậu quả: thắng nghĩa là ép lui, thoát thân hay giết? Đề xuất mặc định **ép BNB rút lui**, không tự trao toàn bộ cổ. Nếu thật sự giết/đoạt cổ, các sự kiện Thanh Thư và trận sau phải rẽ nhánh theo; không cho BNB sống lại và có đủ cổ cũ.

## 4. Luật vận cổ: mạnh phải có thời điểm sử dụng

Giữ luật người dùng đã chốt: một action kích hoạt tại một thời điểm; khi phát chiêu, các cổ khác đang sẵn sàng nhận CD 2s; cổ đang CD giữ thời gian còn lại. Đánh tay, đi, dừng và lướt giữ ngoại lệ hiện tại. Hủy trước release không tự áp CD chung 2s. Hộ thể đã bật có thể cùng tồn tại với action khác nếu loại hộ thể đó cho phép.

Thêm dữ liệu rõ: `startup`, `rootDuringStartup`, `interruptible`, `upkeepPerSecond`, `channel`, `maxDuration`. Đứng yên nghĩa là khóa tọa độ actor trong thời gian quy định; pose đổi không được làm phát sinh damage trước release.

| Loại | Quy tắc thử | Lựa chọn của người chơi |
|---|---|---|
| Đạn thường/đòn nhanh | Vận ngắn; khóa di chuyển trong action theo hiện trạng, không áp thêm thời gian đứng yên kéo dài. | Dùng để thăm dò và phạt sơ hở. |
| Hộ thể mạnh | Đứng yên vận rõ trước khi giáp có hiệu lực. Sau vận được di chuyển/đánh, nhưng mất chân nguyên duy trì và có thời hạn. | Tìm khoảng trống để bật; không được bảo vệ ngay khi mới bấm. |
| Chiêu diện rộng mạnh | Đứng yên vận, báo vùng trước; vùng chốt trước phát đòn, không bám mục tiêu tới sát release. | Đối thủ có thể ra khỏi vùng hoặc áp sát ngắt vận. |
| Chiêu duy trì mạnh | Phải đứng yên suốt channel; không thực hiện action khác. Đi/lướt/dừng là lệnh hủy channel có chủ đích. | Đánh đổi vị trí và thời gian để đổi lấy hiệu lực. |
| Hồi phục | Đứng yên vận 0,8–1,0s cho lá hồi lớn; có thể bị ngắt. | Rút khỏi tầm địch rồi chữa, không vừa áp sát vừa hồi ngay. |

**Không bắt mọi cổ đứng yên lâu.** Nhịp trận đến từ chiêu nhanh xen chiêu mạnh, không phải ai cũng chờ thanh vận. Không cấp miễn ngắt vận cho mọi chiêu mạnh. Phân biệt nhận sát thương với bị stagger; phải xét cửa sổ chống stagger hiện có 1,2s, nếu bỏ qua nó thì thêm `interruptible` cũng chưa tạo phản đòn thật.

Chi phí cần chống trò hủy vận miễn phí: bản thử giữ chỗ chi phí lúc bắt đầu, trừ chính thức tại release; tự hủy mất 25% chi phí kích hoạt đã giữ, còn lại trả về. Bị ngắt cũng mất 25% để cùng một quy tắc. Đây là **đề xuất mới**, cần Orange-kun review; không âm thầm thay luật tiêu hao cũ. Chiêu duy trì trừ theo simulation clock, hết chân nguyên thì tắt ngay; không để xuống âm. Lá tiêu hao mất lượt ở lúc bắt đầu như hiện trạng, không đồng thời trừ thêm hai lần.

Đạn đã phát không biến mất vì người thi triển đi hoặc dùng chiêu mới. Channel dừng chỉ xóa phần hiệu ứng chưa phát. KO, pause, kết trận giữ đúng hợp đồng dọn event hiện tại.

## 5. Bản thử cân bằng Thiên Bồng và bộ chiêu

Các con số dưới là **thiết kế gameplay**, không phải tốc độ/thời gian trong truyện. Thử từng nhóm, không đồng thời nerf toàn bộ PN và buff toàn bộ BNB.

### 5.1. Thiên Bồng — vừa tiêu hao duy trì, vừa rút thời hạn

**Cập nhật theo người dùng:** không giữ bản 5s miễn phí duy trì, cũng không chỉ thêm upkeep mà giữ nguyên thời hạn 5s. Lượt thử đầu áp dụng cả tiêu hao duy trì và thời hạn ngắn hơn. Thông số lượt A bên dưới đã áp sandbox; các phương án tiếp theo vẫn là đề xuất cần đo.

- Vận từ 0,40s lên **0,90s**, đứng yên, có thanh vận và âm báo. Giáp chỉ bật tại release. Recovery thử giữ 0,30s.
- Lượt thử A giữ giảm **65%**, rút thời hạn tối đa từ 5s xuống **3s**, phí bật **18**, CD **14s**. Thời hạn tính từ release, không tính lúc đang vận.
- Duy trì thử **5 chân nguyên/s**; tắt regen chân nguyên khi đang duy trì. Hủy hộ thể được bằng nút riêng, không dùng nút D như một lần thi triển mới tốn action/CD chung. HUD hiển thị cả thời hạn và tiêu hao.
- Duy trì đủ 3s tốn thêm 15, tổng phí **33 chân nguyên**; tắt sớm chỉ trả phần duy trì thực tế, không thu cả 15 ngay lúc bật. Chưa có giáp trong 0,9s đang vận.
- Hết chân nguyên, hết thời hạn hoặc KO thì giáp tắt. Hộ thể không hồi máu, không miễn đẩy lùi/stagger mặc định. DOT giữ quy tắc hiện tại và phải ghi trong tooltip; không tự thay giữa các trận.
- Nếu vẫn thống trị, lượt thử B giảm còn **55–60%**; sau bản A chỉ chỉnh một biến mỗi lượt. Nếu PN quá yếu thì giảm upkeep hoặc startup trước khi tăng damage địch bù trừ; vẫn giữ yêu cầu có phí duy trì và thời hạn dưới 5s.
- Adapter PN chỉ tạo Thiên Bồng khi inventory có nó. Sự kiện hợp luyện phải tiêu thụ đúng nguyên liệu; nếu người chơi kiếm thêm Bạch Ngọc hợp lệ thì vẫn được dùng cả hai cổ theo quy tắc hộ thể. Save cũ nghi dư cổ phải kiểm tra lịch sử nhận/hợp luyện; không tự xóa chỉ vì đang ở màn sớm.

### 5.2. Bộ cổ còn lại

- Bạch Ngọc là phòng ngự cấp thấp hơn, vận nhanh và hiệu lực nhỏ hơn Thiên Bồng. Khi thiết kế thành hộ thể duy trì phải có upkeep riêng; không để nó là bản hộ thể miễn duy trì thay thế Thiên Bồng.
- Sinh Mệnh Diệp: thử vận 0,90s và giữ heal 50/lượt, tối đa 2 nếu người chơi có hai lá. Không đổi heal lẫn số lượt cùng một lần đo.
- Lốc băng nhận: giữ telegraph và vận 1,15s để đo; kiểm tra cách dùng dạng xoay quanh BNB so với vùng chọn từ xa hiện tại. Nếu đổi vị trí phát là đổi cả cơ chế, cần benchmark riêng. Không coi vòng nổ từ xa hiện tại là tái hiện nguyên tác đã xác minh.
- Băng Trùy muộn: đạn băng định hướng, thời gian bay hữu hạn, báo hướng và có thể né; đòn rải/bắn liên tiếp phải là một action trả phí cho cả loạt.
- Blue Bird Ice Coffin muộn: đạn mạnh vận thử 0,9–1,2s; nổ có báo hiệu, tốn chân nguyên lớn. Cần test tương tác chặn đạn/nguyệt nhận như ch.166, không cho boss một loạt đạn tức thì không phản ứng được.
- Cơ băng: dùng làm cơ sở phòng ngự BNB, đề xuất kháng chảy máu ở mức hữu hạn. Không chốt là vô địch hoặc tự hồi đầy máu; xác minh cổ/đặc tính trước khi đặt ID và effect.
- Cường Thủ/Plunder: truyện là đoạt cổ, trong sandbox đang gây damage và kéo người. Cần ghi rõ đây là chuyển thể; không dùng nó như bằng chứng PN có cổ “tay khổng lồ”. Cơ chế đoạt cổ giữa trận nên làm riêng sau, vì ảnh hưởng inventory và các nhánh truyện.
- Sương Yêu: bỏ cách hiểu “thoát thân miễn phí một lần mỗi trận”. Trận đầu nếu có cứu mạng bằng tự hủy phải gắn hậu quả mất tay phải/mất cổ và giữ qua tiến trình. Chưa triển khai trước khi có nhánh truyện và asset tương ứng.

### 5.3. Bộ cân bằng chung cho cổ thường

Mục tiêu người dùng: cổ bình thường không được thành lựa chọn phá trận chỉ vì code bỏ chi phí hoặc cho phát tức thì. Cổ đặc biệt mạnh theo truyện được giữ bản sắc; Cự Xỉ thuộc nhóm khá mạnh, không mặc định coi là ngoại lệ vô hạn. Toàn Lực Ứng Phó Q2 là ví dụ người dùng muốn giữ ưu thế đặc biệt, cần đặc tả/đối chiếu riêng trước khi áp dụng ở Q2.

Mỗi cổ cần một dòng trong bảng cân bằng: chuyển số, mốc sở hữu, công dụng, loại tiêu hao, startup/recovery, CD, tầm/diện tích, thời hạn, điều kiện ngắt, cách khắc chế, nguồn truyện và số liệu playtest. Các loại chi phí:

| Công dụng | Cách trả tài nguyên | Ràng buộc cân bằng |
|---|---|---|
| Phát đạn/ra đòn một lần | Phí mỗi lần phát; loạt đạn tính phí cho cả loạt | Đạn có đường bay/tầm hữu hạn; mạnh hơn phải trả bằng vận, phí hoặc điều kiện trúng. |
| Hộ thể/vùng hiệu lực duy trì | Phí bật + phí theo thời gian; hết tài nguyên tự tắt | Có thời hạn; không bị regen bù sạch upkeep; không cộng dồn giáp cùng nhóm. |
| Chiêu channel | Tiêu hao theo thời gian channel và phí bật nếu có | Khóa action khác, điều kiện đứng yên rõ, hủy dọn phần chưa phát. |
| Cổ tăng lực đã cải tạo cơ thể | Không tự gán upkeep cho sức mạnh cơ thể đã tích lũy | Cân qua điều kiện sở hữu, mức tăng, tầm/nhịp đòn; phân biệt với cổ phải vận liên tục. |
| Cổ/lá dùng một lần | Trừ vật phẩm hoặc số lượt | Không tự tái tạo hai lá miễn phí ở mọi trận campaign. |

Tổng hiệu quả phải tính cả hit rate, thời gian vận, cơ hội né, chân nguyên ròng và uptime; không chỉ so damage hoặc phần trăm giảm sát thương. Ngoại lệ sức mạnh truyện phải ghi tên và lý do, không dùng nhãn “cổ mạnh” để bỏ hết giá phải trả. Kể cả ngoại lệ cũng cần đúng quyền sở hữu, tài nguyên và tương tác, tránh nhầm bug với sức mạnh nguyên tác.

## 6. Boss khó vì biết đánh, không chỉ vì máu nhiều

Thử AI cho từng hồ sơ ngay ở mức thường; không giấu toàn bộ phản ứng hợp lý trong `lvl=kho`.

1. Thấy PN vận hộ thể/hồi phục: nếu đủ gần thì tiến vào ngắt bằng đòn phù hợp; nếu xa thì chặn đường hoặc vận đạn. Có trễ phản ứng ít nhất khoảng 0,2–0,35s, chỉ đọc tín hiệu đã hiện.
2. PN đã bật Thiên Bồng: tránh đổ toàn bộ chân nguyên vào giáp; giữ cự ly, ép PN duy trì, trừng phạt lúc giáp tắt. Không luôn bỏ đánh vì sẽ thành chờ hết buff nhàm chán.
3. Mất lợi thế cận chiến trước Cự Xỉ: hồ sơ muộn chuyển sang Băng Trùy/điểu băng và đổi độ sâu, thay vì lao vào đánh tay liên tục.
4. Lốc chỉ dùng khi có khả năng trúng, dựa vào vị trí/vận tốc đã quan sát; không đọc tọa độ người chơi sẽ bấm và không theo mục tiêu từng tick.
5. Chân nguyên có hạn, AI dùng cùng chi phí/CD/luật vận với PN. Tu vi/thể chất có thể cho lợi thế pool/regen theo hồ sơ, nhưng các con số là cân bằng game và phải công khai.

Chưa tăng HP khỏi 300 trong lượt đầu. Sau tách kit + sửa hộ thể + AI, nếu boss vẫn quá dễ mới thử HP tăng 10–15% hoặc regen điều chỉnh riêng. Không thêm cổ ngoài thời kỳ chỉ để làm boss trâu. Trận đầu khó hơn **tương đối với bộ PN lúc đó**; trận rắn muộn vẫn có thể nguy hiểm tuyệt đối, không ép mọi trận sau thành dễ.

## 7. Thứ tự triển khai cho Orange-kun

| Bước | Bàn giao | Điều kiện đi tiếp |
|---|---|---|
| CB-01 | Bảng nguồn/ID cổ, hồ sơ boss theo encounter; mapping sự kiện nhận/mất/hợp luyện của PN và adapter inventory | Battle không tự cấp/tước cổ PN; mất tay/đoạt cổ boss không bị reset. |
| CB-02 | Sandbox chọn hồ sơ boss; PN lấy từ save hoặc snapshot inventory được chọn rõ trong chế độ test | Xuất inventory/tu vi/resource và hồ sơ boss trong report; default trang ghi rõ đang thử trận nào. |
| CB-03 | Root khi vận, HUD thanh vận, upkeep Thiên Bồng, hủy/chi phí rõ | Hồi quy timing, CD chung, pause và kết trận đạt. |
| CB-04 | AI nhận biết vận/giáp, bổ sung Lam Điểu từ hồ sơ đầu và Băng Trùy ở hồ sơ muộn | Đạn và vận đọc được ở kích thước điện thoại; không có phản ứng trước tín hiệu. |
| CB-05 | Đo đối chứng, tester chơi lại thao tác mở Thiên Bồng; cân số theo kết quả | Chiến thuật đứng spam không thống trị; đi/né/vận đúng lúc tốt hơn. |
| CB-06 | Nối trạng thái campaign, save cũ, kết quả VN; sau đó mới màn rắn–nhện | Không lẫn sandbox demo với tích hợp campaign đã hoàn tất. |

Asset bổ sung: BNB một tay dùng đúng tay còn lại; không lật pose hai tay rồi gọi là đã cụt tay. Giáp Thiên Bồng theo mô tả ánh trắng thay vì mặc định vàng. Rắn/nhện và vùng sương làm ở CB-06, chưa bắt gen ngay.

## 8. Kiểm thử và tiêu chí nghiệm thu

- Snapshot inventory PN trước/sau nhận, đoạt và hợp luyện; snapshot boss trước/sau mất tay, mất cổ. Kiểm tra trận đọc đúng save, không cấp cổ thiếu, không lọc cổ hợp lệ theo encounter. Có ca người chơi hợp lệ kiếm cổ sớm/khác tuyến gốc. Save cũ nghi sai được báo và kiểm tra nguyên nhân, không tự chuẩn hóa PN về bộ cổ mẫu hay xóa tiến trình.
- Giáp chưa có trước release; đang root không dịch chuyển; đi/chạm để hủy trả đúng phí. Đạn không phát lại do hủy hoặc tab bị ẩn.
- CD chung 2s chỉ đặt cho cổ sẵn sàng tại release; đang còn 0,5s CD vẫn còn 0,5s, không bị đổi thành 2. Tiêu hao giữ/trừ/hoàn không hai lần.
- Đo upkeep/regen ở tốc độ trận và FPS khác nhau, pause/resume; hết chân nguyên tắt giáp đúng tick; KO dọn channel, âm và vùng chờ.
- Giữ test kết quả trận chốt một lần, hai bên chết cùng tick, đạn cuối và trạng thái đang lướt. Không đưa bug cũ trở lại khi bổ sung charge/channel.
- Benchmark mỗi hồ sơ/độ khó với ít nhất 5 seed × 300 trận cho các chính sách: đứng đánh, spam ưu tiên, di chuyển đọc đòn; thêm đối chứng “mở Thiên Bồng” và “không mở”. Báo timeout, số hủy vận, chi phí giáp và số đòn né; không gọi tỷ lệ bot là tỷ lệ thắng của mọi người chơi.
- Mục tiêu playtest ban đầu: trận đầu người mới thường thua nhưng hiểu lý do, người biết né và quản lý tài nguyên có thể thắng; trận ch.166 cho thấy PN tiến bộ rõ. Không đặt kết quả bắt buộc bằng script.
- Sau mỗi thay đổi một nhóm, tester thực chơi lại trên thường và khó, cả chuột lẫn cảm ứng. Cửa sổ vận và đạn phải đủ để chạm né; chưa được coi PC đạt là mobile đạt.

## 9. Orange-kun cần review/chốt

Ưu tiên phản hồi CB-01 trước code: mapping ba màn game ở mục 3.1, có áp chế tu vi lúc gặp đầu hay không, và cổ PN thật sự sở hữu tại từng nhánh. Sau đó review lượt thử A của Thiên Bồng (3s, phí bật 18 + duy trì 5/s, vận 0,9s), bảng cân bằng chung mục 5.3, phí hủy vận 25%, phạm vi ngắt vận khi đang có poise, và chiến thắng sớm được hiểu là ép lui hay giết. Các lựa chọn này phải ghi vào dữ liệu/hợp đồng event trước khi đo cân bằng.

Lưu ý tài liệu cũ: `CHI_TIET_NGUYEN_TAC_Q1.md` ghi “mượn Thiên Bồng” và thu phục Cự Xỉ trong đoạn ch.129–155; không tiếp tục suy kit từ các dòng đó. Ghi chú bộ chiêu sandbox cũ “chưa xác minh Băng Trùy Q1” cũng đã được bổ sung bằng ch.166 ở mục 1 trên.

## 10. Review của Orange-kun (02/10/2026)

Đối chiếu bằng bản dịch Việt đang dùng (`cochannhann.pages.dev/api/chapters/<n>`, các ch.133–143, 155, 166).

### 10.1. Đúng, giữ nguyên

- Ch.139 (“Cụt tay”): BNB dồn toàn bộ chân nguyên vào **Sương Yêu cổ ở lòng bàn tay phải**, cho nổ **cả cánh tay phải**; băng sương thành lớp vỏ bảo vệ để hắn hồi phục. Thanh Thư và Phương Chính có mặt.
- Ch.143: PN dùng **Cường Thủ cổ** (nhị chuyển) để đoạt cổ trên người BNB đang hấp hối. Đúng nhận định “Cường Thủ là đoạt cổ, kéo người trong sandbox là chuyển thể”.
- Ch.155: lần đầu hợp luyện Thủy Tráo + Bạch Ngọc thất bại, Thủy Tráo chết. Lần sau Bạch Ngọc + một cổ phòng ngự hành thủy ra **Thiên Bồng tam chuyển**. Cổ gia tộc thưởng khi lên tam chuyển là **Lôi Dực**.
- Ch.166 (“Lần thứ hai chiến BNB”): BNB dùng **Băng Trùy cổ** cùng đàn chim băng, sau đó **Lam Điểu Băng Quan**; băng cơ gần tan rã. Bỏ nhận định “Băng Trùy không có ở Q1” là đúng.
- Ba gia tộc Cổ Nguyệt / Bạch / Hùng: đúng.

### 10.2. Lỗi cần sửa trong bảng mục 1 và hồ sơ mục 3.2

1. **Ch.143 đoạt được ba cổ, không phải hai.** Thứ tự: Xích Thiết Xá Lợi → **Thạch Khiếu cổ** (“con bọ cánh cứng màu xám tro”, PN luyện hóa rồi cất vào ngực) → Thủy Tráo. Dòng “chưa xác nhận được Thạch Khiếu” cần sửa thành **đã xác nhận**.
2. **Lam Điểu Băng Quan không phải cổ “muộn”.** Ch.136 BNB đã phun nó ra đánh tiểu tổ Hùng Lực: cổ tam chuyển, chim xanh tự định vị địch, khác nguyệt nhận. Ch.140: BNB “chỉ có hai con cổ tam chuyển”, sau khi hy sinh Sương Yêu “chỉ còn lại Lam Điểu Băng Quan”. Ch.143: nó “đang sống nhờ nơi cổ họng”. Nên hồ sơ `bnb_first_meeting` và `bnb_qingshu_rescue` đều **có** Lam Điểu. Ở trận đầu đang áp chế nhị chuyển thì dùng nó tốn rất nhiều (xem điểm 4).
3. **Sương Yêu không phải cổ thoát thân.** Ch.137: Sương Yêu là cổ tam chuyển **tăng công**, xuyên phòng ngự của PN. Dùng quá độ thì tự hại (thấp khớp, cơ đông cứng), cần băng cơ phối hợp. Ch.143 thêm: nó cho người dùng “hóa thân thành sương yêu”, dùng lâu sẽ thành tượng băng. Còn “thoát thân” ở ch.139 là **cho nổ Sương Yêu + tay phải**, làm cổ chết hẳn (ch.140: “hi sinh Sương Yêu cổ”, phải hợp luyện ba lần mới thành). Nguồn `src:'ch136: hy sinh Sương Yêu cổ để thoát'` trong `kits.js` là **sai chương** (đúng là ch.139–140) và sai bản chất. Lỗi này do Orange-kun ghi, cần sửa.
   - Ghi chú: ch.143 vẫn có câu “có giá trị nhất là Sương Yêu cổ”, mâu thuẫn với ch.140. Theo ch.140 vì câu đó nói rõ cổ đã nổ; đánh dấu đây là điểm lệch của bản dịch/tác giả.
4. **Áp chế tu vi trận đầu: có, đã xác minh.** Ch.134 BNB tự nói sẽ áp chế xuống nhị chuyển để “đấu công bằng”, và dùng chủ yếu cổ nhị chuyển (ch.135). Ch.137 cưỡng ép Sương Yêu bằng chân nguyên nhị chuyển, tốn lượng lớn. Ch.140: bị “bức bách phải dùng chân nguyên bạch ngân”, tức là từ đoạn cụt tay hắn đã thôi áp chế. Trả lời câu hỏi mục 9: `bnb_first_meeting` = **áp chế nhị chuyển**, pool > PN, cổ tam chuyển dùng được nhưng rất đắt.
5. Bảng mục 1 dòng ch.133–138 nói cuộc truy đuổi đầu “có yếu tố lợi dụng các trận đánh khác”. Đúng: ch.135–136 có tiểu tổ Hùng Lực đánh BNB, ch.138 có thêm người đuổi giết. Nên ghi tên cụ thể để hồ sơ `bnb_exhausted_pursuit` có cảnh.

### 10.3. Hồ sơ boss đề xuất sau khi sửa (chỉ boss, PN vẫn đọc inventory)

| Hồ sơ | Tay | Tu vi dùng | Cổ BNB | Ghi chú |
|---|---|---|---|---|
| `bnb_first_meeting` (ch.134–137) | 2 | áp chế nhị chuyển | Băng nhận, Thủy Tráo, Sương Yêu (tăng công, tự hại), Lam Điểu Băng Quan (đắt) | Sương Yêu nên là **buff tăng công có giá** (máu/chậm sau khi tắt), không phải lướt |
| `bnb_qingshu_rescue` (ch.139–143) | 2 → 1 trong trận | thôi áp chế (bạch ngân) | như trên; nổ Sương Yêu = sự kiện mất tay, sau đó chỉ còn Lam Điểu là cổ tam chuyển | Nổ tay hợp làm **mốc chuyển pha** (vỏ băng hồi phục, hất lùi). Nhánh “cứu Thanh Thư” chen vào đây |
| `bnb_second_battle` (ch.166) | 1 | tam chuyển | Băng nhận một tay, Băng Trùy, Lam Điểu, băng cơ | Không còn Thủy Tráo (bị đoạt ch.143), không còn Sương Yêu |
| `bnb_third_battle` (ch.190) | 1 | tam chuyển | như trên + rắn trắng là tác nhân màn | Làm sau |

### 10.4. Về Sương Yêu trong sandbox hiện tại

Người dùng đã chốt trước đây: “giữ Sương Yêu làm chiêu thoát thân, 1 lần/trận là chuyển thể”. Blue-chan đề xuất bỏ cách hiểu này. Theo căn cứ ở 10.2 điểm 3, Orange-kun **đồng ý với blue-chan về hướng**, nhưng đây là thay đổi quyết định của người dùng nên ghi vào mục cần quyết định, không tự sửa runtime. Gợi ý thay thế giữ được tinh thần “boss có đường thoát”: ở hồ sơ trận đầu, khi BNB dưới ~30% máu thì nổ tay phải: vỏ băng hồi phục vài giây, hất lùi, rồi chuyển sang pha một tay (`bnb_qingshu_rescue`). Thắng trận đầu = **ép BNB rút lui**, đúng đề xuất mặc định ở mục 3.2.

### 10.5. Ý kiến về các đề xuất khác

- Mục 4, phí hủy vận 25%: **đồng ý có điều kiện.** Hủy miễn phí là thiết kế của Orange-kun để di chuyển được ưu tiên hơn spam. Đề xuất: miễn phí khi hủy trong **0,15s đầu** startup (sửa bấm nhầm, bước né sớm), sau đó mất 25%. Đánh tay vẫn phí 0. Lý do: AI Khó đọc startup ≥0,2s rồi né, nên nhử rồi hủy đúng là cách lạm dụng; mốc 0,15s chặn được nhử mà không phạt né phản xạ.
- Mục 4, bảng “Đứng yên khi vận”: hiện mọi action `act` đã đứng yên. Chỉ cần thêm cờ cho chiêu được phép đi trong lúc vận (nếu có). Không cần thêm `rootDuringStartup`.
- Mục 5.1 Thiên Bồng: đã áp, xem review ở `NOTE_APPLY_THIEN_BONG_3S.md`. Màu giáp “ánh trắng”: theo luật dự án, màu/hiệu ứng là tự do thiết kế, chỉ cần nhãn. Không bắt buộc đổi tint.
- Mục 6 AI: đồng ý. Ưu tiên điểm 1 (phạt PN vận Thiên Bồng 0,9s / lá 0,55s) vì hiện AI Thường không phạt.
- Mục 2: “bot đứng spam + Thiên Bồng thắng Thường” không còn đúng với runtime hiện tại. Đã đo lại (seed 20261002, 300 trận): Thường **stand 10,7% / spam 1,7% / move 83,3%**; Khó **0 / 0 / 46,7%**. Thiên Bồng 3s đã hết thống trị kiểu đứng yên.

### 10.6. Cần người dùng quyết định

1. Đổi Sương Yêu từ “lướt thoát 1 lần/trận” sang “buff tăng công tự hại + nổ tay là mốc chuyển pha”?
2. Thắng trận đầu = ép BNB rút lui (đề xuất), hay cho phép giết/đoạt cổ (rẽ nhánh lớn)?
3. Trận ch.166 có làm thành màn riêng không, hay chỉ giữ ba màn?

## 11. Blue-chan xử lý phản hồi Orange-kun

Đã sửa bảng/hồ sơ theo mục 10: ba cổ bị đoạt ch.143 gồm Thạch Khiếu; Lam Điểu từ ch.136; áp chế nhị chuyển ch.134; Sương Yêu là cổ tăng công, tự bạo ch.139–140 là sự kiện hy sinh cổ và tay. Câu ch.143 nhắc Sương Yêu được giữ là điểm mâu thuẫn bản dịch, không dùng để tự cấp lại cổ đã nổ. Các sửa này dựa trên đối chiếu bản Việt Orange-kun đã ghi; không tuyên bố Blue-chan đọc lại toàn bộ nguồn ở lượt này.

Sandbox vẫn dùng action thoát thân chuyển thể từ sự kiện tự bạo, chưa implement buff Sương Yêu và các hồ sơ thời kỳ. Không coi việc sửa bảng là đã hoàn tất sửa kit theo nguyên tác.
