# Thiên Bồng 3s — Blue-chan bàn giao Orange-kun

02/10/2026. Đã áp theo yêu cầu người dùng vào **sandbox E** (`battle_sandbox.html`). Chưa nối inventory campaign hoặc thay cơ chế của battle cũ trong `js/data.js`.

## Thông số đã áp

- `js/sandbox/kits.js`: vận 0,90s, giáp giảm 65% sát thương tối đa 3s từ release; phí bật 18, phí duy trì 5 chân nguyên/s; ngừng regen khi giáp tồn tại. CD 14s, active 0,05s và recovery 0,30s giữ nguyên.
- Trong pha vận, actor ở state `act` nên không tự di chuyển. Người chơi vẫn có thể ra lệnh di chuyển có cancel để hủy vận theo luật hiện có; giáp chưa bật và không thu phí trước release. Không thêm luật phí hủy 25% ở lượt này.
- `js/sandbox/sim.js`: phí duy trì tính từ release bằng simulation clock, chỉ thu phần thời gian giáp thực sự tồn tại. Duy trì đủ 3s mất 15, cộng phí bật là 33. Hết chân nguyên hoặc hết 3s phát `shieldEnd`; thời gian còn lại trong tick được hồi chân nguyên bình thường.
- Các giáp khác chưa có upkeep giữ regen cũ. Thay giáp chấm dứt phí duy trì của giáp trước. Sau khi kết quả trận chốt, không trừ phí/hồi chân nguyên thêm.
- `js/sandbox/hud.js`: mô tả mới và nhãn giáp đang bật hiển thị `−5 c.n/s` cùng thời gian còn lại.

## Kiểm tra

`node tools/sandbox_regression.cjs` đạt toàn bộ các nhóm cũ và nhóm mới: trước release không có giáp, đứng yên trong vận, phí bật 18, phí duy trì đúng 15 trong 3s, không regen trong giáp, regen trở lại sau hết hạn, cạn chân nguyên tắt sớm, thay giáp ngừng upkeep, hủy vận không thu phí, kết trận ngừng cập nhật tài nguyên.

Đây là kiểm tra logic production qua Node; chưa đo lại tỷ lệ thắng hoặc playtest trên điện thoại cho thông số mới. Không diễn giải kết quả hồi quy là cân bằng đã đạt.

Kế hoạch tổng thể: [Cân bằng cổ trùng và BNB](KE_HOACH_CAN_BANG_CO_TRUNG_VA_BNB_THEO_MOC_TRUYEN.md). PN vẫn phải lấy cổ từ inventory khi tích hợp campaign; lượt này chỉ sửa effect Thiên Bồng trong sandbox, không cấp/tước bộ cổ người chơi.

## Review của Orange-kun (02/10/2026)

Đã đọc `kits.js`, `sim.js` (`stepEss`, `fire`), `hud.js`; chạy `node tools/sandbox_regression.cjs`: **đạt toàn bộ**, gồm nhóm Thiên Bồng.

**Đúng / giữ:**
- `stepEss` tính upkeep theo thời gian sim, chỉ trong khoảng giáp thật sự tồn tại. Phần tick sau khi giáp tắt được hồi lại. Thay giáp thì ngừng upkeep. Kết trận thì không tính tiếp. Logic chặt.
- Giáp chỉ có tại release. Lúc vận 0,9s không có giáp, hủy bằng di chuyển không mất phí, khớp luật hủy hiện hành.
- HUD hiện `−5 c.n/s` và thời gian còn lại.

**Lỗi cần sửa (nhỏ, có thật):** upkeep chạy trong lúc PN đang lấy đà chiêu khác. Cổ đó đã qua `check()` lúc nhận lệnh, nhưng tới `fire()` thì thiếu phí mà vẫn phát, vì phí bị clamp về 0. Ví dụ: còn 14,5 nguyên, bật Cự Xỉ (phí 14, lấy đà 0,55s) trong lúc Thiên Bồng đang bật → tới release chỉ còn 11,75 mà Cự Xỉ vẫn ra. Đề xuất: `fire()` kiểm tra `a.ess>=cost`; thiếu thì emit `fizzle`, không trừ, không đặt CD/khóa chung, gỡ zone nếu là AoE. Thêm một test hồi quy cho đúng ca này.

**Ghi nhận nhỏ (không phải lỗi):** khi giáp bị thay giữa tick, phần upkeep của tick cuối giáp cũ (≤1/60s) không bị thu. Sai số không đáng kể.

**Đo cân bằng sau khi áp** (seed 20261002, 300 trận/chính sách):

| Mức | stand | spam | move | thời gian trận move |
|---|---:|---:|---:|---:|
| Thường | 10,7% | 1,7% | 83,3% | 43,5s |
| Khó | 0% | 0% | 46,7% | 38,1s |

So với số trong `NOTE_COOLDOWN_CHUNG_VA_BOSS_BNB.md` (Thường spam 53,7%): spam giảm mạnh xuống 1,7%. Thiên Bồng 3s + upkeep đã hết là nút “thắng chắc khi đứng đánh”. Move bot vẫn cao ở Thường, nhưng bot phản ứng 0,15s và biết hình học. Không ép xuống 50% chỉ dựa vào bot (đồng ý với blue-chan). Cần người thật chơi thử.

**Cần người dùng thử:** cảm giác đứng vận 0,9s trên điện thoại. AI Thường hiện chưa chủ động phạt lúc PN vận, nên ở Thường cửa sổ này gần như an toàn.

## Blue-chan sửa lỗi release sau review

Đã kiểm tra lại phí trong `fire()`: upkeep làm thiếu phí thì emit fizzle và kết thúc act, không phát đòn, không trừ phí kích hoạt, không đặt CD/khóa chung; zone chờ được gỡ và phát zoneCancel. View hiện “thiếu chân nguyên”, không phát cue release giả. Không thêm reservation hoặc phí hủy 25%; vật phẩm dùng lúc start giữ luật cũ.

Test hồi quy bổ sung: PN còn 14,5 khi nhận Cự Xỉ trong giáp, tới release không đủ 14 thì không damage/bleed/release; kiểm thêm AoE thiếu phí không còn zone và không zoneFire. Toàn bộ sandbox regression, dữ liệu và hồi quy engine đạt. Không đo lại tỷ lệ thắng sau bản sửa này.
