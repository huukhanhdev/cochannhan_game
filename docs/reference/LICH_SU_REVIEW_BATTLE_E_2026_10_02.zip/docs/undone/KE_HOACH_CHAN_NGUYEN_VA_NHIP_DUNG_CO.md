# Kế hoạch chân nguyên và nhịp dùng cổ

02/10/2026 — Blue-chan gửi Orange-kun review. **Chỉ lên kế hoạch, chưa đổi runtime.** Thiên Bồng 3s/phí 18 + 5/s đã áp riêng; xem [note triển khai](NOTE_APPLY_THIEN_BONG_3S.md).

## 1. Yêu cầu và phạm vi

Theo định hướng người dùng, trận cổ sư dưới tứ chuyển phải thường xuyên đặt ra nguy cơ cạn chân nguyên. Người chơi cân nhắc dùng cổ vì tài nguyên hữu hạn, không chỉ vì các nút đang hồi chiêu. Không suy ra cùng một mức hồi/chi phí cho mọi tu vi và thể chất.

Chỉ boss có bộ cổ theo hồ sơ trận. PN dùng inventory, tu vi và chân nguyên thực tế của save; không cấp lại đầy khi vào trận nếu tiến trình không có lý do hồi phục. Nhánh kiếm cổ sớm hợp lệ vẫn được dùng, với điều kiện trả được chi phí. Các snapshot cố định chỉ dùng cho benchmark có nhãn rõ.

Hiểu “mở delay skill” là giảm/bỏ **khóa chung 2s** giữa các cổ. Không đồng nghĩa xóa thời gian vận, active/recovery, bỏ CD riêng hoặc cho nhiều action phát đồng thời. Nếu người dùng muốn đổi CD riêng thì cần một lượt cân bằng riêng sau.

### 1.1. Căn cứ nguyên tác bổ sung: dung lượng, chất lượng, hồi phục là ba biến riêng

**Xác nhận lại 02/10/2026:** chân nguyên **có hồi tự nhiên theo thời gian**, không chỉ hồi bằng nguyên thạch. Ch.10 nói rõ hai cách: chờ biển chân nguyên tự hồi và hấp thu nguyên khí từ nguyên thạch. Nguyên thạch là nguồn bổ sung giúp hồi nhanh hơn khi cần, không phải điều kiện để hồi tự nhiên hoạt động. Không buộc đứng yên/channel cho nguồn hồi tự nhiên; chỉ action hấp thu chủ động mới có điều kiện vận trong thiết kế battle. [Chương 10, đoạn sau khi PN dừng luyện Nguyệt Quang](https://novelfull.com/reverend-insanity/chapter-10.html).

| Yếu tố | Căn cứ đã đọc | Quy tắc thiết kế |
|---|---|---|
| Dung lượng biển chân nguyên | Ch.10: PN nhất chuyển có biển chân nguyên tối đa 44% không khiếu, không thể hút thêm dù không khiếu còn chỗ. | Tư chất quyết định sức chứa; thanh đầy của PN không có nghĩa sức chứa bằng thanh đầy của BNB. [Chương 10](https://novelfull.com/reverend-insanity/chapter-10.html). |
| Hồi tự nhiên | Ch.10 mô tả PN Bính đẳng hồi khoảng 4% mỗi giờ; Phương Chính Giáp đẳng khoảng 8% mỗi giờ. | Giữ hồi tự nhiên theo tư chất và thời gian, không lấy 1,8 điểm/s làm mặc định canon. Phải chốt mẫu số phần trăm trước khi đổi sang đơn vị code. [Chương 10](https://novelfull.com/reverend-insanity/chapter-10.html). |
| Chất lượng chân nguyên | Ch.26: nhất chuyển thanh đồng, nhị chuyển xích thiết, tam chuyển bạch ngân; một phần xích thiết tương đương mười phần thanh đồng, bạch ngân tương đương mười phần xích thiết. | Chuyển số/chất lượng không phải chỉ tăng chiều dài thanh; cần đơn vị quy đổi tiêu hao nhất quán. Các tiểu cảnh giới và cổ tinh luyện cũng cần dữ liệu riêng. [Chương 26](https://novelfull.com/reverend-insanity/chapter-26.html). |
| Nguyên thạch | Ch.10: hấp thu thiên nhiên nguyên khí từ nguyên thạch làm biển chân nguyên tăng dần, dừng ở sức chứa. | Hồi chủ động có tiến trình và tài nguyên thật, không phải potion đầy ngay. |
| Hồi khi tu vi cao hơn | Ch.167: sau trận PN còn khoảng 3%, trốn dùng nguyên thạch; cần nhiều nguyên thạch và thời gian hơn để bổ sung chân nguyên tam chuyển, khoảng 8–9 phút mới hồi tới giới hạn. | Cùng một viên không mặc định hồi cùng phần trăm ở mọi tu vi. [Chương 167](https://www.wuxiaworld.eu/chapter/reverend-insanity-167). |
| Thập Tuyệt thể BNB | Ch.136: hồi nhanh hơn Giáp đẳng nhưng vẫn hao dần trong trận; vận cổ tam chuyển bằng chân nguyên đang áp chế xuống nhị chuyển tiêu hao rất nhanh. | Boss có lợi thế hồi tự nhiên thực sự, vẫn chịu chi phí; không ép regen bằng PN để đạt cân bằng giả. [Chương 136](https://novelfull.com/reverend-insanity/chapter-136.html). |
| Nguồn hồi từ cổ | Ch.202: Thiên Nguyên Bảo Liên giúp hồi liên tục; hiệu quả tương đối thay đổi theo chân nguyên/tu vi đang có. PN nhất chuyển dùng cổ tam chuyển vẫn cạn rất nhanh. | Nếu save thật sự có cổ này thì phải áp effect, không cấm vì muốn PN thiếu nguyên. Tách khỏi hồi tự nhiên, đối chiếu mốc nhận. [Chương 202](https://novelfull.com/reverend-insanity/chapter-202.html). |

Không hiểu “dưới tứ chuyển hay cạn nguyên” thành mọi cổ sư bắt buộc cạn ngang nhau. Người có tư chất cao, thể chất đặc biệt hoặc cổ hỗ trợ phải có lợi thế đúng nguồn; mục tiêu là sửa nguồn hồi vô căn cứ và tiêu hao sai.

### 1.2. Mô hình dữ liệu và nối save

- `capacity`: sức chứa thực tế; `current`: lượng hiện có; `quality`: chuyển số/tiểu cảnh giới và trạng thái tinh luyện; `naturalRecovery`: nguồn hồi tự nhiên; `guRecovery`: effect từ cổ; `stoneRecovery`: phần đã hấp thu từ nguyên thạch. Inventory và trạng thái tiến trình là nguồn dữ liệu.
- Chọn một chuẩn nội bộ (thể tích kèm chất lượng, hoặc năng lượng quy đổi), lập công thức chuyển đổi có ví dụ/test. Không vừa nhân sức chứa 10 lần vừa giảm cost 10 lần cho cùng lần tăng chất lượng: đó là tính lợi thế hai lần.
- Các phí sandbox 18, 5/s, 9 là điểm của bộ thử hiện tại; chưa phải tỷ lệ phần trăm không khiếu hay chi phí nguyên tác. Adapter campaign phải quy đổi nhất quán, không gắn thẳng 33 vào mọi tu vi rồi gọi là chuẩn.
- Tính từng nguồn riêng: `chênh lệch nguyên = hồi tự nhiên + hồi từ cổ + hấp thu nguyên thạch − phí phát cổ − phí duy trì`. Khi đang vận cổ, lượng nguyên vẫn có thể giảm dù hồi tự nhiên đang diễn ra vì tiêu hao lớn hơn hồi. Không dùng tiêu chí “thanh giảm” để kết luận hồi tự nhiên bị tắt.
- `maxEss()` trong `js/engine.js` đã có `MAXE`, `S.tuchat` và `S.mod.ess`; dùng làm đầu vào adapter trước khi cân lại schema, không bỏ dữ liệu để ép PN về pool 100. HUD có thể chuẩn hóa độ dài thanh nhưng phải ghi lượng hiện có/tối đa và loại chân nguyên.
- Hồi nguyên theo lượt VN trong engine và hồi theo giây battle là hai thang thời gian. Vào/ra trận không được vừa cộng hồi theo lượt vừa hồi lại cùng đoạn thời gian; không tự đầy nguyên khi mở sandbox từ campaign.

## 2. Vì sao hiện tại chân nguyên có thể quá dư

Đọc `js/sandbox/kits.js` và `sim.js` hiện tại:

| Thành phần | Hiện tại | Vấn đề |
|---|---|---|
| PN | Pool 100, regen 1,8/s trừ khi Thiên Bồng đang bật | 30s có thể sinh thêm 54 nếu không chạm trần hoặc ngừng regen. Hồi cả khi đang đánh, đi và lấy đà. |
| BNB | Pool 100, regen 2,4/s | 30s có thể sinh thêm 72; pool ban đầu bằng PN nhưng đánh băng miễn phí. |
| Nguyệt Mang | Phí 9, CD 2,8s | Bắn ngay mỗi CD tiêu khoảng 3,21/s; sau regen 1,8 chỉ rút ròng khoảng 1,41/s. Đây là ước lượng riêng chiêu, chưa tính khóa chung, giáp và hụt đạn. |
| BNB Lốc | Phí 22, CD 10s | Mỗi 10s regen có thể bù 24, hơn phí Lốc 22 nếu không dùng cổ khác. |
| Bạch Ngọc / Thủy Tráo | Phí bật 10 / 12; không upkeep | Hiệu lực vài giây được trả một lần, còn tiếp tục hồi nguyên trong giáp. |
| Đánh tay / Băng nhận | Cùng `id:'atk'`, phí 0 | Đánh tay bằng sức cơ thể và vận cổ tạo băng đang bị đối xử giống nhau. |
| Lướt | Phí 0, CD 2,5s | Chuyển thể điều khiển game; phải phân biệt với di chuyển bằng Lôi Dực có vận cổ. |
| Release | Kiểm tra phí lúc nhận lệnh, tới release trừ rồi clamp về 0 | Upkeep trong lúc lấy đà có thể làm thiếu phí; nếu không kiểm tra/giữ chỗ lại, vẫn phát chiêu dù không trả đủ. |

Các phép tính trên là ngân sách lý thuyết, không phải tỷ lệ thắng đã đo. Không lấy “pool 100” làm khẳng định mọi cổ sư trong truyện có cùng dung lượng không khiếu. Khi nối campaign phải tách dung lượng, lượng đang có, chất lượng chân nguyên và chi phí cổ.

## 3. Lượt thử đầu: hồi tự nhiên đúng nguồn và đúng thang thời gian

Giữ nguyên pool và phí các đòn trong baseline để xác định tác dụng của regen. Thử hai cấu hình trên cùng snapshot/seed:

- **CN-A, ưu tiên:** hồi tự nhiên liên tục theo tư chất/thể chất và chất lượng chân nguyên; lượng hồi của cổ sư thường trong vài chục giây rất nhỏ khi bám nhịp thời gian truyện. Đổi rate theo giờ sang simulation clock sau khi chốt đơn vị phần trăm. Không đặt luật “thoát combat 4s mới hồi” như căn cứ canon.
- **CN-B, đối chứng:** cùng dữ liệu nhưng hồi tự nhiên của cổ sư thường được xấp xỉ 0 trong trận ngắn. Đây chỉ là xấp xỉ để đo; không xóa nguồn hồi đã xác minh của Thập Tuyệt thể hoặc cổ hỗ trợ. Hồi giữa các cảnh vẫn tính theo thời gian truyện.
- Bản production ưu tiên CN-A với rate nhỏ nhưng dương, tích lũy bằng số thực; HUD làm tròn không được khiến code bỏ mất lượng hồi nhỏ mỗi tick. CN-B không phải quyết định bỏ hồi tự nhiên khỏi game.
- Nếu cần nén thời gian cho battle, ghi hệ số chuyển thể riêng và áp nhất quán cho rate liên quan; không coi vài giây chạy vòng là nhiều giờ nghỉ. Không tăng hồi để bù việc người chơi bắn trượt nhiều.
- BNB lấy `naturalRecovery` từ hồ sơ thể chất, không chốt 0,40/s bằng cảm tính. Đo nguy cơ hao hụt khi vận cổ mạnh/khác chất lượng; không cân boss bằng việc làm mất ưu thế Thập Tuyệt thể.
- Thiên Bồng đang có luật **ngừng regen khi bật** theo yêu cầu người dùng đã áp. Ghi rõ đây là chuyển thể hiện hành, chưa phải quy tắc nguyên tác cho mọi giáp/cổ hồi. Khi làm cổ hồi đặc biệt cần review phạm vi ngừng nguồn nào, không âm thầm vô hiệu hóa mọi nguồn hồi hợp lệ.

Với pool thử 100 và không regen trong giao chiến: Thiên Bồng đủ 3s mất 33; còn 67 chỉ đủ bảy lần Nguyệt Mang phí 9 nếu không dùng thêm cổ khác. Ví dụ này thể hiện lựa chọn tài nguyên, không phải combo bắt buộc của PN.

## 4. Chuẩn hóa phí cổ, không đánh đồng công dụng

Sau khi đo CN-A/B mới chỉnh phí từng nhóm. Không tăng mọi phí một lượt để cưỡng ép người chơi hết nguyên.

1. **Cổ phát đòn:** trả phí lúc phát kể cả đánh hụt; không hoàn phí do đối thủ né. Tách phí theo chuyển số/chất lượng chân nguyên nếu adapter campaign có dữ liệu, tránh đồng nhất 9 điểm ở mọi tu vi.
2. **Cổ duy trì:** phí bật + upkeep theo simulation clock. Thử Bạch Ngọc **2/s**, Thủy Tráo **2/s**, giữ thời hạn/hiệu lực cũ trong lượt thử này. Không thu upkeep cho sức mạnh cơ thể đã được cổ cải tạo từ trước.
3. **Băng nhận BNB:** tách tạo/duy trì vũ khí bằng cổ khỏi vung vũ khí đã tạo. Hai phương án đo riêng: trả **3 điểm mỗi đòn băng** trong kit hiện tại, hoặc tạo nhận với phí bật/upkeep và cho vung khi còn nhận. Phương án thứ hai hợp lý hơn về trạng thái nhưng cần thêm lifecycle/asset; chưa triển khai lẫn cả hai phí.
4. **Di chuyển:** đi bộ vẫn miễn phí để cạn nguyên không thành đứng chết. Lướt game hiện tại giữ miễn phí ở lượt CN-A/B, tránh đổi quá nhiều biến. Nếu action là Lôi Dực thực sự thì phí bật/duy trì được đặc tả riêng, không đổi tên lướt miễn phí rồi coi đã vận Lôi Dực.
5. **Lá hồi máu:** không trả bằng chân nguyên nếu bản chất là vật phẩm tiêu hao; giới hạn bằng inventory. Hồi máu không đồng thời hồi nguyên nếu không có effect được đặc tả.
6. **Cổ mạnh đặc biệt:** giữ ưu thế theo truyện nhưng ghi rõ chi phí/cách vận/điều kiện phản chế. Cự Xỉ không mặc định miễn phí hoặc vô hạn; Toàn Lực Ứng Phó Q2 cần hồ sơ riêng, không suy thành mọi cổ tăng lực phải trả phí giống nhau.

## 5. Trả phí đúng và xử lý cạn nguyên

- Giữ chỗ phí action lúc bắt đầu để upkeep không tiêu mất phần đã dành cho release; UI phân biệt lượng có thể dùng với lượng đã giữ. Release trừ đúng một lần.
- Khi tự hủy hoặc bị ngắt, trả phần đã giữ theo luật phí hủy đã được duyệt. Hiện runtime hủy trước release không tốn phí; đề xuất 25% ở plan trước **chưa áp**, không âm thầm đổi trong bước sửa regen.
- Nếu chưa làm reservation, ít nhất phải kiểm tra đủ phí tại release: thiếu thì không phát, không trừ âm hoặc clamp che thiếu phí. Với AoE phải hủy cả vùng chưa nổ, không để `stepZones` phát damage dù action đã thất bại.
- Hết chân nguyên tắt effect cần upkeep. Đạn đã trả phí và đã phát vẫn tồn tại; không xóa đạn vì người bắn hết nguyên sau đó.
- Không trừ nguyên khi lệnh bị từ chối vì CD/tầm/bận. Command buffer khi thực thi phải kiểm tra tài nguyên lại.
- PN cạn nguyên vẫn có đi bộ, đánh bằng lực cơ thể, né và vật phẩm hợp lệ; boss không được phát đòn băng bằng “đánh thường miễn phí” nếu vẫn cần vận cổ.

## 6. Nguyên thạch: nguồn hồi chủ động theo nguyên tác

Đưa hấp thu nguyên thạch vào phạm vi kế hoạch chính, không chỉ coi là cách cứu cân bằng nếu trận quá dài. Dùng từ inventory thật, có thời gian đứng yên/tập trung và bị ngắt là thiết kế battle đề xuất. Truyện xác nhận hồi dần bằng hấp thu; con số giây, khóa action và cách xử lý bị ngắt trong game phải ghi là chuyển thể.

Campaign hiện có action ngoài trận ở `js/engine.js`: trả 5 nguyên thạch hồi 25 điểm, bị chặn khi `S.combat`. Không gọi trực tiếp action đó trong battle để bỏ qua thời gian hấp thu; cần adapter/action riêng và kiểm tra đơn vị theo mục 1.2.

Thiết kế thử: giữ một viên đang hấp thu, hồi theo tiến độ; phần đã hấp thu không được hoàn lại khi bị ngắt, phần còn lại theo dõi trong dữ liệu viên đang dùng hoặc chọn quy tắc tiêu hao cả viên và ghi rõ. Không vừa thu cả viên đầu action rồi thu thêm ở cuối. Dừng khi đầy, không sinh thừa nguyên; pause không hấp thu. PN đi/ra chiêu thì dừng hấp thu theo luật channel. Boss nếu dùng cũng phải lộ action và có ngân sách nguyên thạch hữu hạn trong hồ sơ.

Chưa chốt một viên hồi bao nhiêu điểm hoặc mất bao nhiêu giây: phải quy đổi theo chất lượng hiện tại và thang thời gian battle. Benchmark ghi số viên/mức còn lại, chân nguyên đã hút, số lần bị ngắt. Rút lui hồi nguyên trở thành một mục tiêu chiến thuật, không phải chạy vòng để thanh tự đầy.

## 7. Sau khi đủ khan hiếm, thử mở khóa chung

Thứ tự thử trên cùng dữ liệu đã cân tài nguyên: **2s → 1s → 0s**, mỗi cấu hình đo riêng. Chưa giảm khóa 2s ở lượt lên plan này.

- Dù khóa chung 0s vẫn chỉ một action tại một thời điểm và một lệnh chờ theo buffer hiện tại.
- Giữ startup/recovery/CD riêng và upkeep. Giáp không được miễn phí chỉ vì chuyển nhanh sang chiêu khác.
- Test mốc `GU_LOCK=0` phải kiểm tra HUD không chia cho 0 đối với chiêu không có CD riêng, cùng event/cooldown của cổ dùng một lần.
- So sánh nhịp điều khiển, tiêu nguyên, số đòn trúng và khả năng phản ứng; nếu bốn chiêu nối nhanh giết trước khi đối thủ có cửa né thì giữ khóa 1s hoặc sửa recovery/telegraph, không chỉ tăng phí.
- Ưu tiên khóa 1s nếu gần chất lượng 0s nhưng cảm ứng đọc đòn tốt hơn. Không kết luận bỏ delay chỉ từ bot thắng/thua.

## 8. Đo gì trước khi chốt

Mở rộng benchmark để ghi cho cả PN và BNB: nguyên bắt đầu/kết thúc, min nguyên, thời điểm xuống 25%/10%, tổng phí bật, upkeep, nguyên hồi và nguyên mất do chạm trần, số lệnh thiếu nguyên, thời gian effect bật, số đòn trúng/hụt, thời gian rút lui/hồi phục, kết quả và timeout. Kiểm tra ngân sách bằng phương trình `đầu + hồi − chi phí = cuối`, kể cả tài nguyên giữ chỗ.

Chạy ít nhất 5 seed × 300 trận cho mỗi profile boss và mỗi cấu hình, với các chính sách: đứng spam, đi né có chọn chiêu, tiết kiệm nguyên và mở Thiên Bồng. Đối chứng regen trước/sau, sau đó mới đo phí mới, sau cùng mới đo khóa chung. Bộ PN là snapshot inventory có nhãn phục vụ test, không áp thành kit bắt buộc cho người chơi.

Mục tiêu thử ban đầu, chưa phải số đã đạt:

- Spam nhiều cổ phải có nguy cơ xuống dưới 10% trong khoảng **15–30s** giao chiến liên tục ở snapshot chuẩn; không bắt mọi build và mọi trận phải cạn cùng lúc.
- Người né và chọn đòn có thể giữ nguyên cho tình huống nguy hiểm, nhưng không đứng bắn vô hạn nhờ regen.
- Cạn nguyên thường xuyên xuất hiện ở các trận dài mà không thành tình trạng bắt buộc sau vài giây; cận chiến và chiến thuật tiết kiệm vẫn có cửa thắng.
- Boss cũng cạn nguyên và đổi hành vi; không có tài nguyên ẩn vô hạn hoặc tự đầy khi thấp máu.
- Playtest điện thoại: thiếu nguyên có thông báo rõ, không nhầm với input không nhận. Hiển thị phí bật + duy trì và cảnh báo thấp nguyên; giảm âm spam khi bấm nút thiếu nguyên.

## 9. Thứ tự bàn giao

| Bước | Việc làm | Giữ chưa đổi |
|---|---|---|
| CN-01 | Chốt đơn vị dung lượng/chất lượng/rate; nối dữ liệu save, telemetry và kiểm tra thiếu phí ở release/upkeep | Khóa chung và phí đòn chưa quy đổi |
| CN-02 | Thử hồi tự nhiên theo tư chất/thể chất, action hấp thu nguyên thạch và AI tiết kiệm; báo kết quả | Khóa chung 2s |
| CN-03 | Upkeep giáp thường, phí băng nhận; cân từng nhóm | Khóa chung 2s |
| CN-04 | Thử khóa chung 1s/0s; playtest chuột và chạm | Một action, vận/thu chiêu, CD riêng |
| CN-05 | Đồng bộ campaign, save cũ, các nguồn hồi từ cổ và thời gian nghỉ giữa cảnh | Không cấp/tước bộ cổ PN theo màn |

Orange-kun review CN-01/02 trước. Kiểm tra đặc biệt: BNB Lốc hiện có thể được regen bù hết phí, Băng nhận miễn phí, và lệnh được nhận đủ phí nhưng tới release thiếu do upkeep. Đây là ba chỗ cần xử trước khi quyết định mở khóa chung.

Kiểm thử bổ sung: hai nhân vật cùng đầy thanh nhưng sức chứa khác nhau; cùng một lượng năng lượng từ nguyên thạch tạo lượng chân nguyên khác theo chất lượng; hồi tự nhiên đúng đơn vị giờ/giây; Thập Tuyệt thể và cổ hồi không bị mất effect; hấp thu bị ngắt không hoàn phần đã nhận hoặc thu phí hai lần; save vào/ra trận không nhân đôi tài nguyên. Không kết luận dựa riêng vào snapshot PN/BNB cùng pool 100.

## 10. Review của Orange-kun (02/10/2026)

Đã đọc toàn bộ, đối chiếu lại bản dịch Việt (`cochannhann.pages.dev/api/chapters/<n>`) và chạy thử trên runtime hiện tại (đã có Thiên Bồng 3s + khóa chung 2s).

### 10.1. Căn cứ đã xác minh — đúng

- Ch.10: PN loại Bính, nguyên hải **bốn thành bốn** (44%) không khiếu; hồi tự nhiên **bốn phân/giờ** (4%), Phương Chính Giáp đẳng **tám phân/giờ**. Một khối nguyên thạch đưa PN từ 14% về trần 44% trong khoảng nửa giờ. Bảng 1.1 đúng.
- Ch.26: một phần xích thiết = mười phần thanh đồng, bạch ngân = mười phần xích thiết. Đúng.
- Ch.136: Thập Tuyệt thể hồi “vượt xa loại Giáp rất nhiều nhưng vẫn sẽ có tiêu hao”. Đúng. Không có con số.
- Bổ sung ch.134: lúc mới gặp BNB **tự áp chế xuống nhị chuyển**; với thực lực nhị chuyển “tốc độ hơi nhanh hơn PN, chân nguyên lại càng nhiều hơn”. Đây là căn cứ cho pool BNB lớn hơn PN ở trận đầu, không phải chỉ regen cao hơn.
- Bổ sung ch.137: BNB “dùng chân nguyên nhị chuyển cưỡng ép phát động cổ tam chuyển (Sương Yêu), nhất định tổn hao một lượng lớn chân nguyên”. Đây là căn cứ trực tiếp cho **phí cao của cổ vượt chuyển khi đang áp chế**, rất hợp mục 4 và 1.2.

### 10.2. Lỗi/điểm cần sửa trong kế hoạch

1. **CN-A và CN-B gần như là một ở thang trận.** 4%/giờ ≈ 0,067% mỗi phút; một trận 40s hồi chưa tới 0,05% dung lượng. Muốn regen trong trận khác 0 thì *bắt buộc* có hệ số nén thời gian, mà hệ số đó là chuyển thể game. Đề xuất ghi thẳng: **cổ sư thường hồi tự nhiên ≈ 0 trong trận (đúng thang truyện)**; regen giữa các cảnh tính theo giờ truyện. Chỉ Thập Tuyệt thể/cổ hồi mới có regen trong trận, số liệu gắn nhãn `game`. Như vậy không cần đo CN-A như một cấu hình riêng.
2. **Regen không phải đòn bẩy chính trong kit hiện tại — đã đo.** Cùng bench, seed 20261002, 300 trận:

   | Regen PN / BNB | Thường: stand / spam / move | Khó: stand / spam / move |
   |---|---|---|
   | 1,8 / 2,4 (hiện tại) | 10,7 / 1,7 / 83,3% | 0 / 0 / 46,7% |
   | 0 / 0 | 0 / 12,0 / 84,7% | 0 / 0 / 43,3% |
   | 0 / 0,8 | 0 / 12,0 / 89,3% | 0 / 0 / 45,3% |

   Bỏ hẳn regen gần như không đổi kết quả. Lý do: pool 100 đủ cho một trận 40s (Nguyệt 9 → khoảng 11 phát), còn sát thương chính của BNB là Băng nhận **miễn phí**. Muốn “cạn nguyên” thành nguy cơ thật thì phải chỉnh **phí cổ/dung lượng** (mục 4) và phí Băng nhận. Chỉ tắt regen là chưa đủ. Thứ tự CN-02 → CN-03 nên đảo: đo phí trước, regen sau (hoặc gộp).
3. **Nguyên thạch trong trận:** theo ch.10, một viên cần khoảng nửa giờ hấp thu. Nếu đưa action hấp thu vào trận đấu tay đôi 40s thì phải nén thời gian rất mạnh, và nó sẽ thành potion trá hình. Đề xuất v1: **không có hấp thu nguyên thạch trong đấu tay đôi**. Chỉ dùng giữa cảnh/khi rút lui khỏi trận (như ch.167). Nếu sau này có “thoát khỏi trận để hồi” thì làm ở tầng campaign.
4. Mục 2, dòng “Release: kiểm tra phí lúc nhận lệnh, tới release trừ rồi clamp về 0”: **xác nhận là lỗi thật** ở `sim.js` `fire()` (`a.ess=Math.max(0,a.ess-cost)`). Hiện chỉ PN gặp được: đang Thiên Bồng (−5/s), bấm Cự Xỉ khi còn 14,5 → 0,55s lấy đà mất 2,75 → vẫn phát chiêu dù không đủ phí. Sửa tối thiểu: kiểm tra lại ở `fire()`, thiếu thì phát event `fizzle`, không trừ, không áp CD/khóa chung, gỡ zone. Có thể làm reservation sau.

### 10.3. Đồng ý

- Mô hình tách `capacity / current / quality / nguồn hồi`, và không tính lợi thế chất lượng hai lần (mục 1.2).
- Phí trả lúc release, đạn đã phát không biến mất khi người bắn hết nguyên (mục 5).
- Đi bộ, đánh tay bằng thân thể và lá hồi máu không tốn chân nguyên (mục 4.4–4.5).
- Khóa chung chỉ thử giảm sau khi ngân sách đã ổn (mục 7).

### 10.4. Đề xuất số thử cụ thể cho CN-03 (thay cho đo regen)

Giữ một biến mỗi lượt, đo bằng `tools/sandbox_bench.cjs` 3 seed × 300:

1. **Băng nhận 3 chân nguyên/đòn** (phương án 1 mục 4.3), BNB regen 0,8 (`game`, Thập Tuyệt). Kỳ vọng: BNB phải đổi sang đánh ít hơn hoặc dùng Lốc/Thủy Tráo có chọn lọc.
2. **Pool trận đầu:** PN 100, BNB 130 (ch.134 “chân nguyên càng nhiều hơn”), cả hai regen như trên.
3. Nếu có cổ tam chuyển dùng bằng chân nguyên nhị chuyển (Sương Yêu, Lam Điểu Băng Quan ở hồ sơ áp chế) thì phí ≥ 2× cổ nhị chuyển tương đương, theo ch.137.

Tiêu chí ở mục 8 hợp lý. Thêm một chỉ số: **% trận có actor xuống dưới 10% nguyên** cho từng chính sách bot. Hiện chỉ số này chắc chắn gần 0.

### 10.5. Cần người dùng quyết định

- Chấp nhận “cổ sư thường không hồi chân nguyên trong trận” làm mặc định (đúng thang truyện), hay muốn regen nhỏ có nhãn `game` cho cảm giác dễ chịu?
- Có muốn nguyên thạch dùng được *trong* trận không (chuyển thể), hay chỉ giữa cảnh?

## 11. Thứ tự sau review Orange-kun

Ưu tiên sửa thiếu phí ở release trước; tiếp đó đo phí Băng nhận, dung lượng bể và phí cổ, không xem tắt regen là giải pháp đủ. Kết quả đối chứng ở mục 10.2 là số đo của Orange-kun. Các con số 3/đòn, bể BNB 130, regen 0,8 là ứng viên, chưa áp trong lượt sửa lỗi/mobile. Quyết định hồi trong trận và dùng nguyên thạch trong trận vẫn chờ người dùng; giữ khóa chung 2s.
