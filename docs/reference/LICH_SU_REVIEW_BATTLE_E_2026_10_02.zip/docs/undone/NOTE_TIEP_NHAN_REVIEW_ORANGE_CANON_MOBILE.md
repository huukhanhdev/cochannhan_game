# Blue-chan tiếp nhận review Orange-kun — canon, release và mobile

02/10/2026. Sửa tiếp theo phản hồi Orange-kun người dùng chuyển lại. Không commit/push; giữ các sửa khác Orange đang có trong workspace.

## Đã làm

- Sửa bảng và hồ sơ trong kế hoạch BNB theo đối chiếu bản Việt Orange ghi: ch.143 đoạt Xích Thiết Xá Lợi, Thạch Khiếu, Thủy Tráo; Lam Điểu có từ ch.136; BNB áp chế nhị chuyển ch.134; Sương Yêu là tăng công, tự bạo mất cổ/tay ở ch.139–140. Ghi riêng điểm mâu thuẫn ch.143. Chưa triển khai kit boss theo các thời kỳ.
- `kits.js`: sửa nguồn/mô tả action Sương Yêu hiện tại, ghi rõ action thoát thân là chuyển thể từ sự kiện tự bạo, không phải công dụng gốc của cổ. Không thay nó thành buff hoặc cấp Lam Điểu ngay trong sandbox.
- `sim.js`: kiểm phí lại lúc fire. Thiếu phí do upkeep thì fizzle; không release/damage/CD/khóa chung, gỡ zone chờ. `view.js` hiện thông báo thiếu chân nguyên.
- `input.js`, `hud.js`, `battle_sandbox.html`: Dừng giống S (cancel:true và xóa hướng giữ); Lướt chạm dùng ngay theo hướng đi, đứng yên thì ra xa địch; hướng bị chặn hoàn toàn thì dùng chiều sâu còn trống. Nguyệt Mang chọn ô rồi chạm sân để nhắm, có Hủy nhắm riêng. Các ô buff/heal/melee/grab dùng ngay như trước.
- Touch/pen commit pointerup ngón chính; không phát khi pointercancel; ngoài sân không phát. Dọn lựa chọn khi dùng chuột/phím, blur/ẩn tab/kết trận. Giữ tick mũi tên, chuẩn hóa hướng chéo và luật hủy khi nhấn mới. Listener input được hủy khi init lại.
- Cập nhật kế hoạch chân nguyên: ưu tiên phí cổ, cỡ bể, phí Băng nhận trước việc chỉ tắt regen; không coi số đo Orange là benchmark đã chạy lại bởi Blue.

## Chưa áp

- Phí Băng nhận 3, pool BNB 130, regen 0,8 và các ứng viên cân bằng: cần lượt A/B riêng. Không đổi khóa chung 2s, không cấp/tước bộ cổ PN.
- Lề hiển thị 127px mỗi bên: đồng ý ưu tiên thử thay cho thu sân; chưa đổi sx/toWorld hoặc biên sim. Khi áp phải dùng hệ số ngang mới cho tầm chém, đạn, AoE và guide, không chỉ vị trí actor. Kiểm toàn bộ clip/bốn góc và điểm nhắm.
- Kit Sương Yêu tăng công/tự hại, Lam Điểu và trạng thái cụt tay/đoạt cổ: mới cập nhật đặc tả; sandbox vẫn là kit demo trộn thời kỳ.

## Kiểm tra và phần Orange cần kiểm lại

- `node tools/sandbox_regression.cjs`: đạt các nhóm cũ và test Cự Xỉ/AoE thiếu phí tại release.
- `node tools/sandbox_input_regression.cjs`: đạt touch commit/cancel/ngón phụ, nhắm Nguyệt, Lướt dùng ngay, S/Dừng, blur/kết trận và chuột. Nạp input production + sim production, dùng EventTarget giả lập môi trường; **không thay thế test DOM hoặc trình duyệt**.
- `node tools/check.cjs`, `node tools/regression_test.cjs`: đạt. Kiểm cú pháp input/hud/view qua.
- Chưa playtest trên trình duyệt/điện thoại thật hoặc đo lại benchmark sau lượt này. Orange cần kiểm nút HUD chỉ phát một lệnh khi touch/click, thao tác chọn/Hủy/Dừng, lướt ở biên và cảm giác chọn điểm Nguyệt trong trận chạy.

File code: `js/sandbox/sim.js`, `kits.js`, `input.js`, `hud.js`, `view.js`, `battle_sandbox.html`; test: `tools/sandbox_regression.cjs`, `tools/sandbox_input_regression.cjs`.
